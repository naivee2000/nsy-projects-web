#!/usr/bin/env python3
"""Extract DEM claim events per source without discarding partial successes."""

from __future__ import annotations

import argparse
import json
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from dem_claim_discharge_builder import DISCHARGE_EVENTS, extract_discharge_events
from dem_claim_load_builder import LOAD_EVENTS, extract_load_events
from dem_claim_workflow_builder import required_missing


Extractor = Callable[[Path, Path], tuple[dict[str, datetime], dict[str, Any]]]


def format_datetime(value: datetime) -> str:
    return value.strftime("%Y-%m-%d %H:%M")


def event_json(events: dict[str, datetime]) -> dict[str, str]:
    return {key: format_datetime(value) for key, value in events.items()}


def empty_load_section() -> dict[str, Any]:
    return {
        "port": None,
        "berth": None,
        "terminal": None,
        "allowed_hours": None,
        "document_onboard_hours": None,
        "events": {},
    }


def empty_discharge_section() -> dict[str, Any]:
    return {
        "port": None,
        "berth": None,
        "quantity": None,
        "rate": None,
        "allowed_hours": None,
        "events": {},
        "deductions": {
            "shifting_hours": None,
            "rate_difference_hours": None,
            "night_navigation_hours": None,
            "document_onboard_hours": None,
        },
    }


def base_section(section: str) -> dict[str, Any]:
    return empty_load_section() if section == "load" else empty_discharge_section()


def extract_one(
    *,
    source: Path,
    index: int,
    section: str,
    extractor: Extractor,
    specs: dict[str, dict[str, Any]],
    work_root: Path,
) -> dict[str, Any]:
    record = base_section(section)
    record.update(
        {
            "source": source.name,
            "source_path": str(source),
            "index": index,
            "section": section,
            "method": "python_ocr",
            "ok": False,
            "missing": [],
            "error": None,
        }
    )
    if not source.exists():
        record["error"] = f"Source file does not exist: {source}"
        record["missing"] = [spec["label"] for spec in specs.values() if spec.get("required", True)]
        return record

    source_work_dir = work_root / f"{index:02d}_{section}_{source.stem}"
    source_work_dir.mkdir(parents=True, exist_ok=True)
    try:
        events, _grouped = extractor(source, source_work_dir)
    except Exception as exc:
        record["error"] = str(exc)
        record["missing"] = [spec["label"] for spec in specs.values() if spec.get("required", True)]
        return record

    missing = required_missing(specs, events)
    record["events"] = event_json(events)
    record["missing"] = missing
    record["ok"] = not missing
    return record


def extract_many(
    sources: list[Path],
    *,
    section: str,
    extractor: Extractor,
    specs: dict[str, dict[str, Any]],
    work_root: Path,
) -> list[dict[str, Any]]:
    return [
        extract_one(
            source=source,
            index=index,
            section=section,
            extractor=extractor,
            specs=specs,
            work_root=work_root,
        )
        for index, source in enumerate(sources, start=1)
    ]


def summarize(records: list[dict[str, Any]]) -> dict[str, int]:
    total = len(records)
    complete = sum(1 for record in records if record.get("ok"))
    return {
        "total": total,
        "python_complete": complete,
        "needs_codex": total - complete,
    }


def build_partial_extraction(load_records: list[dict[str, Any]], discharge_records: list[dict[str, Any]]) -> dict[str, Any]:
    all_records = load_records + discharge_records
    summary = summarize(all_records)
    summary["load_total"] = len(load_records)
    summary["discharge_total"] = len(discharge_records)
    summary["load_needs_codex"] = sum(1 for record in load_records if not record.get("ok"))
    summary["discharge_needs_codex"] = sum(1 for record in discharge_records if not record.get("ok"))
    return {
        "metadata": {},
        "load": load_records,
        "discharge": discharge_records,
        "confidence_notes": [],
        "summary": summary,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract DEM claim events per source and keep partial successes.")
    parser.add_argument("--load-source", nargs="*", default=[], help="Load SOF image/PDF files")
    parser.add_argument("--discharge-source", nargs="*", default=[], help="Discharge SOF image/PDF files")
    parser.add_argument("--json-output", required=True, help="Output partial extraction JSON path")
    parser.add_argument("--debug-dir", default=None, help="Keep OCR crops/text in this folder")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    load_sources = [Path(source).expanduser().resolve() for source in args.load_source]
    discharge_sources = [Path(source).expanduser().resolve() for source in args.discharge_source]
    output = Path(args.json_output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    if args.debug_dir:
        work_root = Path(args.debug_dir).expanduser().resolve()
        work_root.mkdir(parents=True, exist_ok=True)
        load_records = extract_many(
            load_sources,
            section="load",
            extractor=extract_load_events,
            specs=LOAD_EVENTS,
            work_root=work_root,
        )
        discharge_records = extract_many(
            discharge_sources,
            section="discharge",
            extractor=extract_discharge_events,
            specs=DISCHARGE_EVENTS,
            work_root=work_root,
        )
    else:
        with tempfile.TemporaryDirectory(prefix="dem_claim_partial_ocr_") as tmp:
            work_root = Path(tmp)
            load_records = extract_many(
                load_sources,
                section="load",
                extractor=extract_load_events,
                specs=LOAD_EVENTS,
                work_root=work_root,
            )
            discharge_records = extract_many(
                discharge_sources,
                section="discharge",
                extractor=extract_discharge_events,
                specs=DISCHARGE_EVENTS,
                work_root=work_root,
            )

    extraction = build_partial_extraction(load_records, discharge_records)
    output.write_text(json.dumps(extraction, indent=2, ensure_ascii=False), encoding="utf-8")
    summary = extraction["summary"]
    print(
        "Partial extraction complete: "
        f"{summary['python_complete']}/{summary['total']} source(s) complete with Python OCR; "
        f"{summary['needs_codex']} need Codex."
    )
    for section in ("load", "discharge"):
        for record in extraction[section]:
            status = "OK" if record.get("ok") else "NEEDS_CODEX"
            missing = ", ".join(record.get("missing") or [])
            detail = f" missing: {missing}" if missing else ""
            error = f" error: {record['error']}" if record.get("error") else ""
            print(f"{section.upper()} {record['index']} {record['source']}: {status}{detail}{error}")


if __name__ == "__main__":
    main()
