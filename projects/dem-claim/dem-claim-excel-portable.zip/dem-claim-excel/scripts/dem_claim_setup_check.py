#!/usr/bin/env python3
"""Check whether the local machine can run the DEM claim helper scripts."""

from __future__ import annotations

import importlib.util
import shutil
from pathlib import Path

from dem_claim_template import DEFAULT_TEMPLATE, ensure_template, verify_template


def module_status(name: str) -> str:
    return "OK" if importlib.util.find_spec(name) else "MISSING"


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    print(f"Skill root: {root}")
    if DEFAULT_TEMPLATE.exists():
        status = "OK" if verify_template(DEFAULT_TEMPLATE) else "OK (differs from embedded recovery copy)"
    else:
        try:
            ensure_template(DEFAULT_TEMPLATE)
            status = "RESTORED"
        except Exception as exc:
            status = f"MISSING ({exc})"
    print(f"Template: {status}")
    for module in ("openpyxl", "PIL", "pypdf"):
        print(f"Python package {module}: {module_status(module)}")
    tesseract = shutil.which("tesseract")
    print(f"Tesseract: {tesseract or 'MISSING'}")
    if not tesseract:
        print("Install Tesseract for typed image OCR. AI vision fallback can still read images when available.")


if __name__ == "__main__":
    main()
