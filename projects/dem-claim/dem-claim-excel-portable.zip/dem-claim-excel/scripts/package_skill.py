#!/usr/bin/env python3
"""Create a portable zip of the dem-claim-excel skill."""

from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = SKILL_ROOT.parent / "dem-claim-excel-portable.zip"
EXCLUDED_DIRS = {"__pycache__", ".venv", "web_outputs", ".git"}
EXCLUDED_SUFFIXES = {".pyc"}
EXCLUDED_FILES = {".DS_Store"}


def should_include(path: Path) -> bool:
    relative = path.relative_to(SKILL_ROOT)
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return False
    if path.name in EXCLUDED_FILES:
        return False
    if path.suffix in EXCLUDED_SUFFIXES:
        return False
    return True


def build_zip(output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(SKILL_ROOT.rglob("*")):
            if not path.is_file() or not should_include(path):
                continue
            archive.write(path, Path(SKILL_ROOT.name) / path.relative_to(SKILL_ROOT))


def main() -> None:
    parser = argparse.ArgumentParser(description="Package dem-claim-excel as a portable zip.")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT), help="Output zip path")
    args = parser.parse_args()
    output = Path(args.output).expanduser().resolve()
    build_zip(output)
    print(f"Saved portable skill zip: {output}")


if __name__ == "__main__":
    main()
