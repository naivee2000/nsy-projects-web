#!/usr/bin/env python3
"""Recover the bundled DEM claim Excel template from embedded bytes.

This file is generated from assets/DEM_CLAIM_TEMPLATE.xlsx so the workflow can
recreate the template if the external .xlsx file is accidentally deleted.
Regenerate this file whenever the Excel template design changes.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import zlib
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = SKILL_ROOT / "assets" / "DEM_CLAIM_TEMPLATE.xlsx"
TEMPLATE_SHA256 = "ee186940d83781c391b1cb68b8c964f04dae60f9a73271be9ed932dfdf4ef07d"
TEMPLATE_SIZE = 12542
_TEMPLATE_ZLIB_BASE64 = (
    "eNqFugVY1FvXPjwgJd0I0qF0KCUN0t0hgijdNYB0SXeHdEmDNAwh3d0tKY3SzX9mOOf4Hr/n+R69ZvY187tX3Pda"
    "e+0L2Ioyj+BwAQAAEgCXa/SteLecZBz40yD4hQl+GVjrK9pZ29izvLexYf5oaSE3LIfSxoqK8L1F2bE2KZg0B12U"
    "PzitcZjZwa+GzvLT1eE+nKCVs3PP0yzmIMpnNYliv5jXLV++6EYTmqK6EujvywzOXHctZVv0Dv1KhJFDRvqoPcty"
    "2suPDZV7YLW2fHuCWdzYYThexKmCR+lZ+6omO8/X52RFC8TImD9caARCcGReJTDA34eo9OOppG32Wd8YwLcgNhAo"
    "/otCvweCJgIMAHACfmH9Xwr61naGEA5+UcLm7ayofvfSvfxRi1aEL0sxdmdM/dpgn4IItS3bVztmSKXublMY5bTV"
    "n1ysnqcJSAUy9Kuu2fwgCmGO3SJILTAbjtV53o3J+OjnTqD4FeOzHZODp8YGge+cAAyTCXzkjI97W/Ui3yA8fsRa"
    "/ZItKfLNoOT1fiFWBp6eH8Lud28j3KFZr6GLz/DZL5/zvhsqqLGsdOTYXBXFFagps177aap1TW7uF/T9DduGon9X"
    "0HuqeSe8AJQohSZP+ImQGW+/pVWeV68Oiwbtf0UHvt+P5ctjZ0F6v3ZNrKlxapxhCqxnuadgpmJT2H4t/Bg0PEvS"
    "RJ4G8OmuVBsL2KfmO/1Qu/JTg6R691EI2b9Fy4mItuiDBwBKnwIAOOBvP1qwAE0MLQ0f3tkgsu1rKVjjSOC2aOw4"
    "PdknmTJ39cVZyZj5muknFPuEPnxt8dfB99nUyQHuVi44iRxpNdPOXOVJGQw1berINwUn/eyxwcpBZSO1nhbDXZUU"
    "3qqW8Oq4hwM3S/fO1kvFw+/qSNiqJD7l8FlpD80m+0nu2aZ3Cc83CGylm2pJ0hNfJ/5KrCqhi5ryO8UQ5I6YVpWk"
    "9PESiDevs/STpjGvYeJP7DpiVJBENadipizWo4WdJ/hIdiE+UDptxuD4ydQi84nEt7M5E1F+n7Tbm/4Qa9I7xx8C"
    "N1q7Lwn5Ee4/0Iw/jgjSYcEpxjHS9NzLeWdHD5LN4B+Yww88vrzzWlDH/6BJr2miXb2nP7v7Y/8VlgpeFZGO4DUu"
    "EN5bsNQYSPlk6HGqh/3pwmaKJ/+PltDdU5fFtJc/EmDKf3jnDmHXzFq/SiVUQIsVZD4+mFp4Uxk6fcEV/7MoVb5b"
    "h2nlKYqb/ePlwhJ2rh0aN3tvp4TTQwsgiIGmEfStjHHl+oe6RrKhGwIyYVi3zBZ72nHPAAXVEDPhCpNXrdFTPe+K"
    "6sW48e5CszKxC3wCd4BBa2dwl6Qczos20u8N3ETIwSowH8P0LGnSj9bHVOlRpBRGRKtLInBQg756Nbpc3RZ9iRgF"
    "v9APBF7VXY+3NrkiOnmyY+q22WbgNN+cVbY0N/jeud2c9iO+S/yl3H1/135r3OJhhUBPcnHTL+HJ53xys/KFpdlV"
    "z8saiW9i5RERVlBptHtVO1X5ILkXamcvLQJFHg0yMewYYK+gHK6Rp3Pg025kxbEVEi3g2ffO3pLoUlBmIq0ZQBc9"
    "G9smxH5qpc1kaEM13mqIGn2grVO0e1+v0Th6kR93bonaO1VWjhFEQVdQP0g+x03OpkSrs6YvgmrARcd06RDi4iMj"
    "oLz1TIxENoyZcCTzBY5OFlaHoZkypojO0eAU2sTKQIdHzF5cVCRmYpImtrrdmhifEvcLs1CqPKoyPbzk2IVU5LJ1"
    "mwLyMZj3xKdulLlBm8mJ8RNNoZnYhO3NnXlKhHS4JJ8jNVh/8NjFRIAowrGzh9jRHfYk7FC1cbMtS0Olf9r55+gH"
    "PgpnaHf3xXaoqGqW9x1pFB6LC2LNhVvZcEupwHpmq7QsE8eT9UvJ8LNS/vxh/xlqM0xAIp0zOsEu/cJ9uaj1qlSj"
    "HDnDksbWOd6VTvGIWr3blYOzUrBl0/TQjGhc2Hngi5qivNC3UVpYCXppywG9FpFYg9c31J+6Rd4+JkBK4adqnXyu"
    "6geikBcKjZFCMmjliaRdwbYiUKc53AuWbt20GEpdZIAJm8Q/P97291hOqewV956A51BG6Mab4j53bEsh/ihrGm4e"
    "v0lKNzjV+NjZ1+ZKuVWr4EfW+2w98ZuJw1e+Wpry/KIvOgToPqw/QbMl6gZq757qjueUcC7Jz9n65ISYqwfaK1BI"
    "V+fSzvZv96weIe37qlstVkcGxNRw+KShkGbDXfRWqb7H77DsV/GjK5PbbEf4XJurUsReR02JpWz5gXBTdXZsz0G2"
    "caTlgFNFMCUcxt8MyMdExPTj3USbAPGbF0RYCmoDjP6dROm0lI6vPcnQZkX39EZASYfM6dLc9DuV3l6olvhPy1Iu"
    "xfCJPfZVDBCNpAJDkifGPqS3V/6oR5+VVBkuHblFkzNNyaI7AJlLN9hntlpezE6izAG8lRok5vEJ6NcV/aIjXdxh"
    "wl4/QzkRicQvkA7MPaxQ0eldyrLa4DuiJPhkFoAgqZgPpMf9ZFHUNjTNar9zdcmjrzqRVN/worclwCCiXDi5iaHg"
    "Fh/ZeDLHRtSfl5h9PlanPeOe7MAtGS91eHS/VUTxmLpJUoXhak6p/MqRPuVnfslnplJQt4AZTl1exgkZrhU9X82W"
    "NaIbYlbEJgmNT9jHPLWcZTc7JJ5a9jVl9XuLp9VIwkWUS19m3cyGrFS5r01srQ8spr+bn5tozPfTmZkTJFlUnejj"
    "ky3Bzn62EUxmpTk+l69dUZ5LvUWFcduD375a/vfo/1yP7jsG/iQO8zD6f5+XDvZAa0vI6E+NbLXyZcUU9YS/tGp0"
    "fI2CFAmbk0D8pkDtoCcR4bF+v+6YuNJ9k7hltKs1b/Lo/Chu2ZDmho2qwNXY+N4xTvx6oIl9VyMf/eIlN/WmHnrX"
    "NrovkGwAtZ1WzXw9azJUFsBXsdQTt4lxaFzEd7lxS/CMIEJcxbVIonBVISW7fryQ+ro24WfZO+qpfu5TxA1JdhPi"
    "6+i3czmm83DY9I5ar1/9TDbCmMXxwxWayHIeqgFZY89yMMJefbo0EORvkBaipP3BFkEhD7+Mu3eAt/eGIuV8o/CP"
    "04/xqdOABxEAYP4NAHjycPo5WduZ25sYGgLtWaAL9Ais1tGxXu9xuGVAa8V4eTaUr1VMj+9HCLNjVCuq18yX7BDZ"
    "rRtExCGuzLDIz8t7XeUROO34QRBOGF+L2ga7TJ9cCP/x6szu3l1KalLql1uUegv8ouDVpsUJHVcYbQ53IHqvdsJ6"
    "vXvIRCpB5WVlp6kSoytZSroO44FVKnNCAu/8fEj2+KpbRR0/iJEZ8CppcPi5zMWPm+2zVTtd2XCNnONKy9HD3f3j"
    "3pMP5udDO5USx0uje3UfWV+xHFiRxKeLAgbTWIbzCOC9Qn78+BFz2S9sy+lq68QwVyj4kc/dpeGte3mT6w+7oypu"
    "xvhDXdgVgwa3F65wZBPfaxaHDlLXtp1tvyYOMbscr64fTOlWxZhXX6VOlt2YvGnUhFtbsjtaem+rTswUshY3E1A5"
    "e7kyuo6aE4Z8d5nBt1C50/5C5HDQaFjam9jk9khIg3LD8fnPtdsPmimt1hE0xAPvSs5yiBv4mZJW6pZyf9Hn23w6"
    "lMPvtHE8Ixhf26CzABY5vU2RTUtnujUuuN77tdcp/P41jXXIjkmEkXHI5P25rmoLGY12U/aPkI29BeRYW91mRgz2"
    "pZ1UBRb19BQFgXz9ue9L8hPiDeXA0ayQ+aiZgQgmweY+gg+Lm7m5MjIJTC5A1+OuOMMifN7tb1PxJWUV42ETHcpy"
    "DGamCRlf4tN0PfuVWtJYJ+esx027PkmniPoMNBzkvE8R50VQ6r6VTBVnwIw6yMvU4WZ3hAXy4O8PwSzyoHAqBI6c"
    "0mVk4TfNh+b3yFQNZYe/zKLcZn/zXKWbUCmKNzNrim7SVlw1J1WcF9QwGBgcOm5iOL1JqKSUqhlkNQoalMxqEuXl"
    "Aq/RE/X1RF+NqKUov4wOHVq9jKZuM62qLJoPpQ4CEpXs7djUy+50BF9ldR5y0nxDFZ3bnrVU9ipskt5FnrN945X8"
    "Mc4x2enzkwyisjH5SisVnNO1ZpUg7aCpjXBsXgwKWZmMtT0knMAqlWrwStUoPR8NTCF5/wEMvgyvpAo9od932+Xm"
    "bTMpa7Mh+mZXkPdhk4ks0RvpPA9DdU2trtY9I0/Xz3UtIhaoVUZ9PoWhuqL2hMtTr15VRnlzHwKcBgDUXPBK4QGF"
    "R/RvcQCq+2p1nID8riLWUEB5SueeTB4ewIi8jeNRVlmKig6ac3x9GWVZGwecEJ6un/ljL/om5HZcQJE8B9Z5UikA"
    "4g4PoOaKV8oAMFtVqyuFOLLR8Q50z6wj0nV1XO3JTR6T1QAMCH3aRfaib0QGoznO6N9qAFS3oei5Ita3MOVvC5MC"
    "r8W8gmCxzjRgutTMJyO5eLvwLCGLeF0xl8+tnxdWW5FNMzZrmzvTlELiP4FdIIEhPDSgPKDhIQ53VEP0W4HwYPHr"
    "SsnDdfbV0ZwrcUCwpURHRojh7eAMYVhzNd7XwYJlUfHfRvYiDAR/pVitsdIAm/FM1w+cqxkk1w56h8saCA/VHeVB"
    "yTwGiDAO8BAlwAgiKOvCk7+CPykFaDoU9nr0/RX2QQkYRZUysMmLnWktjNcQ+E96VA1AMc+kQfH/ZvG2cFtgHA/w"
    "EhOcVsEDiWwdGA3IQrUCxY39hSMc/CfqHDQqDiSqEAck0Rzb1EKzj/uzbKVyuZSt/+DaoDh9KO6UXytHf7KakN5N"
    "onrx684YusMgPd7zf+pm9lC3U3CCGR/GnegluwvX9jpK9dXQyvh5v5qr05HYE2BucUPSzJAua9MVzfgrS/19tRmU"
    "x1W7mmrt5sPhjoP0tN/+Zi00+eNossq8trRS/y0UrK/8fyntqD7SaP3vnL7ZnqZKg/SrnR291L4kx7v/79IwT7I7"
    "0VGwPsKCPPgFeTAxAenUKSsxCtR6qB4PUuYuGPr9FXYMGjYO2hVmfwdfQfbaiEcU36Pxj0IXnQlBpWrpY11leRl6"
    "w9Me2DLCesSARnWn3N5TxhGqGYJGNV0sTe1U/XdcaOdPdEDdhoHd+og2hKtxNJ7tSYJx7L9xP6G4GSgu9+/wzqXC"
    "ICO1aDuNp7DQjgDPD0hKck3g4lAXaFsi/au/ZDt0LJH+2nYQBEDNGe+fFMCD4qFdCXv/RoUCq7U51gfDgfBvoUsR"
    "2vsesPe4B8LKTCulnHAPEk9CJU7+iPe3knrY018L/afTUjs4imT7fof9b7t9R1UG/jfX37UQpl8we/3EDszZD7o3"
    "JwvipQ/MXushUP720Ff0e6OC+dvAgydgvM1fkviw20JJyK8i15n1fE7tKOH8RPGwwfwZAPEy1bGgOcz/MrKEk/8q"
    "RU6plpoAV587O1Z+Jur0k9i3WFvlZApwVsRbNoPCvXHe6NOksQvfkzSH2tqjN8kC4xZyA2g4Yt8L5iO9xQEj1eCs"
    "iMCL+h5DLexXYvsSkV48b/Qf3mIZl+sydf2YMma07RyoNBoIPHvd+N5FsCSlprT1PCPvBRsg5jakunDJMs35wzrR"
    "msqvCUudAaVFv/YSuVS+hYGR3rT1lCMrbwKjGR6R+AfRmjJfUrbqpEGBUVAnLeuAOqmMdo9BGBs58DIqTI2d7u1T"
    "qfg153JdZSE3GJInL/L3YKGAfVqvp4g8FhIwbwm3ykngbRwy2m1xhY57E2wSmOInFP3Bz81hSWqyARAyJGKxTzyZ"
    "qfc2Qmg04HiIJWDYE9yyhnXaIJHBkFJU4Ew4bB39CMT3DtQ32DY8G5AsI0BR108IoeyIK1J3NRKe9JLGLUkzDLws"
    "FHbZDTjifgPr2a0EGHyevspsyViQiTqvBNCAJrZADfWXDPH3SVngEZ5xlL7Uca9xXT/xg8NvaEsZHbo7mnZrD3Qa"
    "xYKaFr6uIxwqrTJ+ZASLsyrg1KsvhWYISe4Z1FmeN/q8Uod77dFX4kowaTEoaftegu6FjYi/tOmDOiuCci9FBz7Y"
    "rnAjZ0AVjISigjUvkb8SvTSWvnwBXWgoR/4yXaP12owZLn/XhvSgYdEjqIbYUI3BJXHE/frLWr+4azqdbm25m/Z6"
    "j+AF7P+oiX3vc/2zfkJvor5/fHyTg7iN/OopQRU6C06Q8u8E9wg4YP8njZcLhrEPZE3d/CC1MHwoiWEsEhT3Aoqr"
    "X1fBcpIy/Es+HijBZxD5ANNw4BwzKZedirqm0+ggQDYn57+BD0p0QYHgHoeQIdmyIYYfcTsyPVDujybq+/nuotgd"
    "GjfXHRo310+QgN211xCyT3Y7h+dqF2JXmEF/98KDD7y/BQGT53joGJr08DoZ1odW4DnC+8CxOYhrkw2lzfBAGxXI"
    "HQ5rwnwJtEjQtyIruaMd22FhMozZMDgfcjvL4nr3ONaTX2pr3uN8IV11zscyoaVKwyrPrdSyCJFMgaVPUNehLuUR"
    "H/zohhVnw/LTpfn+w+VZ3baaPozaiO+e5Wi1FEqW+Y03StpYRSWKTwnT5Df7P+gOOCVra9ki4tXyiXm5KfmVwInv"
    "inmqMuJ3EuZx1wRvFq4KwBMrCoUDwmY6PuvjOIXIHdra+nQ9z1tVgaGjucl34tPCN/Giz5PShgkuAChBgIDeQZho"
    "80cnPzvho7ijkQdcWou5PQXSFdLwm7pV3ei9K6hcaQTwFD2oPGkEcCOphKgEzOzdJjYvInuz858UVPceG9SkpJz6"
    "x1yOax0G9G/IsEsHB0dnVQTC2sGZiEpZh0frPs1tdTsLlaSS85MsE2whDwoOoeJjT26AVfoGA7+ONIIkV/GKXQoz"
    "WcglUlEiDU6C1E2gVICFV0oDnSETPQTihjh+1k3Tn5vx9d7GCCZvTFL1y1sbAXeepsSM8+QoChGx/Q6BahxEaHKq"
    "25uKuaL5yvSq23OBC58b+ZLfnqAn2ByK+ERrOU5IMyI/UeGtSFdeyfIihiFaoW8RmcEtO3Ia8dICBCWKcX6yANqG"
    "whc/q6USp9S30zhj8oELE7VDNfVn2sGsCUTWho/lXy56XykZEhPV00O5H1OaR04R1BOpKKlr7d/oJEGSYiuq1e8t"
    "JitrMLA0O7sn5p3bb4Nzugjf18/5S5yM2Luoi9n+c+KQ6nun1zJdeX7AdepofUn7NzyJRyZNDAGV1ecGLuEN7d4b"
    "eWw3V71WAs1fz8lBbIGTiyUlTggNGIJWzY/aETeMuTwBgsD7zUHe+ecgp6UyZB6usERF9ceGmZC3T4pT2C4XFwh7"
    "RgUv395qbn/7ie8WTBdqBk9IaxDXdt61HFMN51bFtH7eH8Ga9DWu1SiZkUmSujtyU3Z6srMBts7ue5YDDMmEZH8V"
    "BlN0DbOG1mDUfki02JsUtnrEa/xWnw+vSkLehdsmCysBFV36x7dHK59X9ot/otUWKJd0ZfHHl4rqd9QsZYc16Hzz"
    "mTCGt1yBEnG9dOPJF0LyRQpz+nmmnvnL9ibUJs6t0+leicpLbFA+KhMWCMMqkhj3eINuR05q8KvYWPzpckQPsh9E"
    "enG+bcxf1HwD4vjKPSOUtkVwg2ZwbKr4pqmn+iE5kkTRp2hB60/GUKV1Vjtqp/1y7e7FI7mWOkfdXLTusJxOwq1D"
    "EOkjKnsrZpgPgSZ3FuSCzEPPj42R7FuMKGGo+olRTREY93HL/e+tD098AyJcFcQxKkbXlKZAv86yW66v7gVcT38p"
    "6Lqf/Sq6vzrkenfXPR8h4H5ctOx22+15f1aUnolVcrI25eChStWzLW57RlXRTBFF/Dr53cwZCE76ZBrR7LD1J+DD"
    "6UH20+WbQ7Klu9svH/kQfOjp/KmjteCC3g+a6iR24bOV8B4K1Kc+wu5lyyFsz1dBzUZja3Qq41ridTva1xB0vx6+"
    "P7ry9JCnjptshRWJY19zmbcso+n5EADRB0EUiByoSRbpGxCQvdSOyKV7f8RlLXA//dlERGnIU5IySaz8Qqm6O1F1"
    "/nnUQ4SWOpWb1dNfDO4S1hc/725HfVfyndY+v7s/5Wq5ZnIwUu5ygVoJKad8FVMFpQrZoUP6w4jc8ItQn5W3G9D6"
    "BA72cue4RQdHsi8PQ4q6EglfUsooh5rF1iBTiPKVP/ujAh74iorxvJazUNIIV3BGgwrfU/JKbYJDAyjXMns6KHdh"
    "oYlgLNKR8oRKbKlIGUAirk5RhDP6+InFmIokO0EB8Tkk8b8sPAQK6PvUg+pNRPtdzgN50M7vjqQ8PCdcj0Z0Jr/r"
    "Pk6o1mi5WD193uJ53Xv4za3x8gaHviiap6itjGlskoC2zf2XraCnoseVr50M1wnvrdMVl8yTW2ZDA5oYRxJrLEaS"
    "3isviI5dTSru5ESlzu5eEq4BGtnXO933J1eC92HBpfXYOtwh/SOlWUU/t2YXTTc2Zyg1p6I7YSF9F6r75YNwzqfF"
    "AUbKeficjNBL8DOfSM50iMdS/i2DY/3dz0FlPJDf6OwzMj+X6Fws6Xf+Srt5SKANuj6e/fD1CgH3aONU4p16L6zp"
    "WPtRhxWlXHulYuIOo+xOZfnNFv7N9eY5/NXGCu2SYiTxQNrwV5Yv3WxaRB0GplCp13QTEFYdK5h/js59O1xqbzEj"
    "Y3desfwk+iIkZ39eUvbV3VexSAuaV4iQOfPSLHUnYOaMEJvSJODLeMzGyep22LTg9em8583eoHXLp6zCPvnixJ7i"
    "pbiJ0MKJPcQCQmGzs+2JBdWpyAK6ngnqEFRoUdblxcQtpu8VJWIGw9PSCQj6l/ZWm2YNPN7qPrpbWStrubmdfndz"
    "8zn9LqpOW1ONEZELlwN40tNH+YwBBWrPn1Mx8x34CcPMsNawnwtVElp7dc/6UzN2S8PRA6Rug1vMmNNH0F1NoCwI"
    "xNDY6KLZ1n7GkmBzvT3LTNv8Ykgd/Vad1h9fWXVSuT8hVVmW136uLSm97t3n9DrPIou+IDUV5meh63lUxHKbxiyu"
    "50Yx+nVppwidYrYvdDyuJ79sBSkeyl33k6JUj69Aay/PpIzskD5XmKWo2p4lsN4/6zbbH2wPNLM8Hcd4Gl2Dcxlu"
    "GaXOpOEKEzFZUrHYUMr7qthJFpv37OIOIAe/r5zpwLxjE/70B6XUXC0mpz4uZKZ3lb7LjXNVr3mEWLm52Br/qscv"
    "VASy6Q1O9cYnv2spX4N0Jcxepd4mmu0RR0qGUwx+Tyq6LQjPBI1JhaE5Y2REUgQZ4Asfwvg3Ik7kOJpHUJNAUSO5"
    "n7VdbdV6IwcnGAWJSff4l8gyNXyC3W7DC2koSSblooEScRPE2nCmpF0G+xKQDklQO+cK0DmbJtvESFdgjh/fkGH8"
    "GD+vu/BZC267eAppspAxQTu7qORadYtaqzkKGsNhZ09S25ztujR+aBdkRTnuriE1afzQQnqp9Fz1maJXpeDvaj5S"
    "a+lLVXRRQibeypaqfi8ah0L3QSG1Kzd1tFRFgIr9nNPbED02agamh8kmz09cnxkwXg2i79UNpXZlwxeWVpCaUoY6"
    "Jk91YVMuwZAMODBTyYpSxAU7cNLHWmyQC2XyocGdBUHH6q/dCVCUi/uNuji1SVnzVScBUENRmSkOIlUrpemun+N8"
    "K6Xms+h9Umg8qZxIIcokYKhBwl1hTjL1a+xeAxHxCmbSObEkv/Ical5uaODYVB7uMU7xZn1fNaIX5P6NPYQvqnvS"
    "UKGbW+JLWqhs+8dPYrhBqFLUMet2TFL89i9KJyPZKZr4IAg3OMztNaBVOb350b0smvqGuhn8crrM1yt88R1xX7Vg"
    "I181sxtXNoYgdk0mn5xsShQYaGLn8n5ec+UduyB2TTUgTYMN/vQym7SvxPCBPKjVDIvaHE8LD1rsLYdCZNxToJMR"
    "Vk5rIa21QA1SPHnO+HOIEgEzvdsM5qn3oeCgbxhatfILmeORGzTpG+Dvn4E0g+cDlAwcMnp2HiabjqNZOX09508D"
    "3+peFGsqyNFjakXXdxKBpyUSmfJwKFTL03yqaL5RmNSrdtHU48RjMKiJyvWllEGEPq2Vz/WtGE5QWUZsut3SsPa4"
    "/FUk6BZulILuu9TDjdzL6APv+BrvNWJ8MTWulhQ092+OhdSq2AicVa74rVniFODzJF9JwKO4p9Br/aHfy4GFyLEl"
    "yHdV/C5FwX7dNjHBxRTJ0WFbURxw/uzZAROYqbwxfcw7ZufGDxOi/C7UL/IulNIcRWwKH1K5407C6TImtzrgRkaL"
    "SsSSmR6/C8ov1xP5+fMttbfXxngJ/C65VqUeWzsSPgnUDaPjQs0mbvemh3dnMbOdWU717jwSyxcrhWjWo/4V7/Ck"
    "e+NcHnvtP9U7i9E2jINz3FefaCkZcZ+fVm3ZgIqYB698BVRAuY4VvGS8ANoCGwparcX6CF5Tot1Ntg+vtE9sVA7X"
    "9iEWTHNe7PKDjHyX92VArdYUOa0KMWdMn+QI/cDdkvJC2OlmRKC55nDY7N0eY4VL0uakfTSlYfgE84yZMqhEiPI6"
    "mXEGetiGWrQ+uzJfDsorghVVJkh7rnBwWjF660QmuNTuOqZOHrzg98UF3qu0ghP5HUxGkQZA9IIBkILt8EKJTkZN"
    "gwqbMKZHIOhB596tnzbNeX2pMJAWporCCgqVMkgXfTjSFXco5UqYLDnUhqBjmDAolFHEscBYoinURSp5o6G2R9jq"
    "UJqE5mro7Drs6ROtKsh4UCOu9SWgSCM4/tJZzs2rfRJuNMwSX9Rv/NPWWjelOE1vjnCuZcIGL3p0aKQ58RaZPfqD"
    "scVytUccXlJqpjuhhbn2YwuGVoqZeKFaeLHLIcUV1/wrwOmvVILy4wvSrl9go74KeBiGLi1kTWTjIFxHgc4M76Ve"
    "dmZEbeWLeDhRxQws4vxU1AhROBBmJqj8OY2oyCovDOTZury//YdA59Aut8g9g4s96ZnwDnuR1g4G4CriL3n/Lle4"
    "oFddOPYYmMSRt6neok6ucIS8XS8dyR0rzMJrbrerXH/YCTRpCrxlstY6kTc+3g6oDNlYt0DCM2ZjCdfIe8SdEPOl"
    "87b3ZhvXY7eY2/tluSfv9nMezlNP1vfHOzv+5P12l8RuzDHsY6eemMvnRjJ1jFkjpmyvmDdpcCV0zXMdX3xmetxz"
    "sPP+q5vHrG+2d3tibLejU9FJ/nEvsH4SlPIW/7h9O6Bzx6WOOzn20Kj6uOb2A6dnTcPR3p3gv/9m1YZeKRsNDwBw"
    "ywIAaA9/s7IHOlsY2kPvahDLWc9znpQh9bHqtRNLVel3hu3XoGDqBcDCz7V7GSIZhFQ83mqP2fp24NCuqLdlyruP"
    "sVdjz3LLhVZ+G6JEaTkeRLMbgu3bGaCZ03s+2H1OWoBK1ei48vnVJ00t51KysIlXXSHGyfhyP0Yqs8b1YNyPQnA+"
    "pflJvUwxHaX8FE/SGcOn8ahhaZoP5XLn4xZLEwOGRB+75tXHHPQaHeTbqyHSAvGWL/S4C4Z67VGF6Tu/JNSqfLOH"
    "zyTuf4p9+YLhUVXGm/ZDx2lqN4TA9OU14s+cMA6MsarLBVrT4yGyIRkyPm4vaoeqgsOItOF056VBDdPssNeoOWgI"
    "177WsWVxMdby8rSnBLbHDfZla/3p8TDNWyNlP4ZjlghCP4Ztu/MBYT2/eOgVVgWM6Dkr1lcvRLmcn1unC96myX4e"
    "KmGl9E84ebpIuo+6QK7KyiYgkhgFFDucwZwKZYoRPo4k+xSLELwl0JBAUbFg4KXv3KMzrht5IvtEE92a+3PoBMPR"
    "rLR1yNsyeDkHGw4R1h3DgnT4g8QlZ+pF/jpfzmr0HTwlU5tL8lgCO+c+xaZQo15LKW2sI2PmYnjhx6sh/dz9ud6r"
    "XTopXtI1H3ER89/TxOEVBsaBvjD7oGZ/fLm79SWD60liHpbnwLFw1KnKqNEcZdaOMl0t6tOj3m1uh8UJlt3qvGdT"
    "fvlhq98KTYbfbSLBxJRx44uVgsLEQPT7TzAI8LtYT8okfeWlXcjuutKWSwk+BWuZlKDZ5G2mY8EzV+jnVMqkkRTe"
    "PN4VbUbTiPy07k6PEvaoVizWDcvjmbBJu00E1RwHacNI668bzMHN3kfo+I/TAGvfQtItDAZhl7MYrfM2UtLWA6km"
    "0eNxKvatTvSZbMuVIsQlpny6fDnfuNCMlCNSFtABF7nYqg5TdV6IkJcSM6NIjzF4XksaDJDSPZkaORjccXAaFxJ0"
    "T6vWrNtNYE6+JA0dfQrXVG1KX8vaYUKkfRjLTvFyOe713c8qFXnuZ6jZGuFh8A1oP2tlKPkFTbu1iN1IRBBLos/6"
    "pFYSHlkHwmN0+BwGwy/jANLUpGlhKwNLNrp6n27wIY3y+uxHauV9dV+iVQtaU3yprkCU5CveG3r7liZ5h7VHnd0+"
    "0li9LUYWp5hvhlTtxRtb22RUrM9DaZ1PCK/l2+NTYg7P8s2mwisJmmYTi16+EAnomt1sDI7Csq9q5q3IDpEQMkW/"
    "ZhZSyaPIFbNV+16pn772hBp1rUNR7c1ttDRLXLGZqx5ppSnXVUIcY2tBju3Um607pNr+gSeNCQySJkwS5pxBfVXW"
    "AGpcPIVYpXyiqUjYMKP+Z34vPRWnrxBKDGEuPw6NvPZjUrZKm8+gE1DSAxja1x/FvhrrRLCrizWyz8U2izOZ/lA7"
    "kxxkLhp7MS+7dVzQzD8+wPzp5E32ruSiLxUqu7b2wC6M93e4ZygerplvkqMCpQ7MT4rGpqz6XJv4rEClWZ8DRyK5"
    "zoxCcGflo4rqYZ1TOMrQdA62GPr1pz8wDR4gvdLRJ1LKkJuWfPeqJ3y2E1OTIwYQBytihYbSayanaEytR9yu6CxM"
    "0k7e4RLWN4ViproGg5WSSlbbjuBY9+Y7SqmTsRfBFp9Bo+cvwRYxVRGsajzFy311m8wsrcxNVLb1+tdRL7lM5FTR"
    "EA8iaqcYHzu/qkAOQl5RqKUpWoiPPd3M+Llro0AwLKpIvz3IZHqI0HvV5ZNCIGfAHxJ3xqp0VVn3RaVsFbGjrUgn"
    "mnQFSVAfy+OMede2S8VdZWmn8WdDUeBVY5du+8YS45Jr2cf5oo6ypogJUATZ/eUuAXqXQdDb0BuSDsSXAjc3l+MB"
    "oPOWu+sfZMT2C40H4djS3z4GlgShnBdQjFhuacoQtCzecSs7DZdFJxS1Ok7saiJbTBwkhWfdOz13RuGVtjm805i5"
    "+GN4O+4FSo+CPxXCAgAo4PWdnaGFPQsz5L06ut8Klg1VzJOmjxS16oMSW3HDew21G6/PH0mTpYhfiaN6LptwGipq"
    "0+cwpy4Qp751Ppd/ZNbNVqvTZ4T6eiDOUm0cRciRCX5ARh63X24QW7GfFo0ayM8J93nSDMVusPx6kWOcmCXoTmS9"
    "4YC4qYIXPvgK7eLZ+0GsXIqSPe5vSbn3egcJ8GaDrRrq6B6WaHy0x8fn5JFZEmI2jFWSyrohjrEtbnygWruULx0D"
    "Jsd1o7cuJqrBaTeH8oljstvbgnELdAwBvDRySUnjx+twlZMLnrD/Zn7c8OMkAwYAuAAzx/h91eKDtbU55OAKU563"
    "mmdFvcVTQBr5MilfnmuCSUirbsBULjOKP6ifOQOUVSV4/WGn6p2gdDgIznUWx0Fy++dPxf6ly4Qwe5bZJZOn+LrB"
    "8fna6875b1jpU0DojNNEP8Io/T0+g/JakUt1ql/q0aXjdfKdZ+BlVmZ2Mgd673vWifwQnsyEJ89GpM8eCbZ7RQ86"
    "1towu8hFlfw180GTDJmyv9+Qj4/iZOXQF6lSA7VOOOzkmRiPOWaScAjCcmZ8FqaWiY7nGl8zr4y0oOqSKVMnkJbP"
    "+3nxnZSgaGaEGY6yUYu4Nkg3eHicEKc5tU0gk2NqQpoNxNjstm4FqGVi65wO+Rg1sSmQ/LyzUW8mAyOWiCapkNIN"
    "/uBVBkk9nhmsZwlSs2vt7ohVDJEjlWAFlTNP18Cza2xzIr81S/5QMVmgQfQ7coIbS/cMYmczkxERknObYPSFYVfL"
    "wctUCZlhjUbVKFMCNGJtvCy+p1fp7slv5fJCes1epLMcU+UdwdkSeLzrvLWXNGNhDiHsD754fv+YLotkb0Z+1zrl"
    "2tKTm0O207PYZ5Li/v3whVjfH238cnetoQT86RpcUKKHYj508v8t6UNXR/Gj+7Ki+pVhbwCe5E9kwuYxF+MRBPpc"
    "YnmLfi1q23/aCpAkaWDVGo5vOTcwZmEPduVVmubFPjZ51mfYvUcKyOElxhObWsF9FnaavUrujiK/LVyNZEq83EpG"
    "WNETLqvEhH5PMZe3zSFQ4hHB/QuD1a2YLP+1AR39hvb62zaLM87WN9G0kbm0u2+vKuRzvPqxsVgQTCMqt2M8XXIF"
    "A3QW9jXqOYYl6koovp/srqL8myS9FgyABkxQDe7hfpT2a2sroKEV8J2qs42hvQ6EYkmsnEI7K6r/vfTk7oSRzXev"
    "KR0vhr1vZEgFIPH+hA9OwHtSLsM4IX0y+gTxsP1z26M3Wk1ksHpT2mvlfdpZP2nhCvGLO8YQbYhN3aqiL7isxCLN"
    "nteSHyT0I2Y2UtmojmRElWkMj/QMKZ6NHXOaHRby+bTyuRLhIKrH9WOGqkdzM5+V3onRNT+m0cgjtnD4Bv98PYk7"
    "SDJT8HF3Wy1/R755D+eLsaKqlGcuVJHoCOV8ZbZZMsvsb4T31YzrczowhadmYCM5Nmgb6ryeNRs8aXGqfCr5wjgo"
    "pSFIgByEv+K4NBqf2YDECBd14vdaXnIqzV3kCXFZZjNhKQ+1tfGxRJL59t7hlwgQOxbt2Ivl9XQVzu134z0B56D7"
    "tKP3TCUTVmZCOdMGt/CKMjCwuI/++1Xzv/95wQD+w8XzP63/vOX927r9P935/tP8z/vOv80vYP7j7ec/Hfx5a+63"
    "g2PE/3iH7k8Hf945+8eB9xnSf7+B9qeXP38K+J1GIdUfPxP8afrnGfTb1JjuXyfSn4Z/jvDfhu/p/z8D/U/jP0fG"
    "b2Nmxv+/AfKnnz935W8/OEz/cY8qysAjQADI4P+e4MxNmSGf/h/oH9Cz"
)


def template_bytes() -> bytes:
    data = zlib.decompress(base64.b64decode(_TEMPLATE_ZLIB_BASE64.encode("ascii")))
    digest = hashlib.sha256(data).hexdigest()
    if digest != TEMPLATE_SHA256:
        raise RuntimeError(f"Embedded template hash mismatch: {digest} != {TEMPLATE_SHA256}")
    if len(data) != TEMPLATE_SIZE:
        raise RuntimeError(f"Embedded template size mismatch: {len(data)} != {TEMPLATE_SIZE}")
    return data


def ensure_template(path: Path = DEFAULT_TEMPLATE) -> Path:
    path = path.expanduser().resolve()
    if path.exists():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(template_bytes())
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Restore the bundled DEM claim Excel template.")
    parser.add_argument("--output", default=str(DEFAULT_TEMPLATE), help="Template output path")
    args = parser.parse_args()
    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(template_bytes())
    print(f"Restored DEM claim template: {output}")


if __name__ == "__main__":
    main()
