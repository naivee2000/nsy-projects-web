#!/usr/bin/env python3
"""Build a DEM claim workbook from reviewed extraction JSON.

Use this after a deterministic OCR run misses values and Codex/AI vision has
read the missing handwritten fields into the schema documented in
references/extraction-schema.md.
"""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from dem_claim_discharge_builder import DISCHARGE_BLOCK_START, DISCHARGE_EVENTS
from dem_claim_load_builder import LOAD_EVENTS, save_auto_recalc
from dem_claim_template import ensure_template
from dem_claim_workflow_builder import document_date_row, save_workbook, set_document_date
from openpyxl.cell.cell import MergedCell
from openpyxl import load_workbook

SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = SKILL_ROOT / "assets" / "DEM_CLAIM_TEMPLATE.xlsx"
LOAD_BLOCK_START = 16

TOP_METADATA_CELLS = {
    "charterer": "B2",
    "charterer_ref": "B3",
    "owner": "B4",
    "owner_ref": "B5",
    "broker": "B6",
    "vessel": "F2",
    "cp_date": "F3",
    "demurrage_rate": "F4",
    "total_cargo_quantity": "F5",
    "currency": "F6",
    "laycan_start": "D9",
    "laycan_end": "D10",
}

DATE_KEYS = {"cp_date", "laycan_start", "laycan_end", "doc_date"}
NUMBER_KEYS = {
    "demurrage_rate",
    "total_cargo_quantity",
    "allowed_hours",
    "quantity",
    "rate",
    "rate_difference_hours",
    "document_onboard_hours",
    "night_navigation_hours",
    "shifting_hours",
}


def normalize_sections(value: Any) -> list[dict[str, Any]]:
    if value in (None, "", []):
        return []
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        return [value]
    raise TypeError(f"Expected a dict or list of dicts, got {type(value).__name__}")


def parse_datetime_value(value: Any, *, field: str) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    text = text.replace("T", " ")
    text = re.sub(r"\s+", " ", text)
    for fmt in (
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%Y.%m.%d %H:%M",
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%Y.%m.%d",
    ):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    raise ValueError(f"{field} must be an ISO-like date/time, got {value!r}")


def parse_number(value: Any, *, field: str) -> float | int | None:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return value
    text = str(value).strip().replace(",", "")
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        raise ValueError(f"{field} must be numeric, got {value!r}")
    number = float(match.group(0))
    return int(number) if number.is_integer() else number


def coerce_field(key: str, value: Any) -> Any:
    if key in DATE_KEYS:
        return parse_datetime_value(value, field=key)
    if key in NUMBER_KEYS:
        return parse_number(value, field=key)
    return value


def event_values(section: dict[str, Any], specs: dict[str, dict[str, Any]]) -> dict[str, datetime]:
    raw_events = section.get("events", section)
    if not isinstance(raw_events, dict):
        raise TypeError("events must be an object")

    events: dict[str, datetime] = {}
    for key in specs:
        value = raw_events.get(key)
        if value in (None, ""):
            continue
        parsed = parse_datetime_value(value, field=key)
        if parsed is None:
            continue
        events[key] = parsed
    return events


def validate_events(
    label: str,
    sections: list[dict[str, Any]],
    specs: dict[str, dict[str, Any]],
    *,
    allow_missing: bool,
) -> list[str]:
    messages: list[str] = []
    required = [key for key, spec in specs.items() if spec.get("required", True)]
    for index, section in enumerate(sections, start=1):
        events = event_values(section, specs)
        missing = [specs[key]["label"] for key in required if key not in events]
        if missing:
            text = f"{label} {index} missing required events: {', '.join(missing)}"
            if allow_missing:
                messages.append("WARNING: " + text)
            else:
                raise ValueError(text)

        previous: datetime | None = None
        for key in specs:
            when = events.get(key)
            if not when:
                continue
            if previous and when < previous:
                messages.append(
                    f"WARNING: {label} {index} event {specs[key]['label']} is earlier than the prior extracted event"
                )
            previous = when
    return messages


def set_value(ws, cell: str, key: str, value: Any) -> None:
    parsed = coerce_field(key, value)
    if parsed is None:
        return
    target = writable_cell(ws, cell)
    target.value = parsed
    if key in DATE_KEYS:
        target.number_format = "m/d/yy"


def writable_cell(ws, cell: str):
    target = ws[cell]
    if not isinstance(target, MergedCell):
        return target
    for merged_range in ws.merged_cells.ranges:
        if cell in merged_range:
            return ws.cell(merged_range.min_row, merged_range.min_col)
    return target


def set_optional_value(ws, cell: str, key: str, value: Any) -> None:
    parsed = coerce_field(key, value)
    if parsed is None:
        return
    writable_cell(ws, cell).value = parsed


def apply_metadata(ws, metadata: dict[str, Any]) -> None:
    for key, cell in TOP_METADATA_CELLS.items():
        if key in metadata:
            set_value(ws, cell, key, metadata[key])
    if "laycan_start" in metadata and "laycan_end" not in metadata:
        ws["D10"].value = "=D9+3"


def apply_load_section(ws, section: dict[str, Any], block_start: int) -> None:
    offset = block_start - LOAD_BLOCK_START
    set_optional_value(ws, f"C{16 + offset}", "port", section.get("port"))
    set_optional_value(ws, f"E{16 + offset}", "berth", section.get("berth"))
    set_optional_value(ws, f"F{16 + offset}", "terminal", section.get("terminal"))
    set_optional_value(ws, f"B{35 + offset}", "allowed_hours", section.get("allowed_hours"))
    set_optional_value(ws, f"D{33 + offset}", "document_onboard_hours", section.get("document_onboard_hours"))


def apply_discharge_section(ws, section: dict[str, Any], block_start: int) -> None:
    offset = block_start - DISCHARGE_BLOCK_START
    set_optional_value(ws, f"C{39 + offset}", "port", section.get("port"))
    set_optional_value(ws, f"E{39 + offset}", "berth", section.get("berth"))
    set_optional_value(ws, f"C{40 + offset}", "quantity", section.get("quantity"))
    set_optional_value(ws, f"F{40 + offset}", "rate", section.get("rate"))
    set_optional_value(ws, f"B{60 + offset}", "allowed_hours", section.get("allowed_hours"))

    deductions = section.get("deductions", {})
    if isinstance(deductions, dict):
        set_optional_value(ws, f"D{55 + offset}", "shifting_hours", deductions.get("shifting_hours"))
        set_optional_value(ws, f"D{56 + offset}", "rate_difference_hours", deductions.get("rate_difference_hours"))
        set_optional_value(ws, f"D{57 + offset}", "night_navigation_hours", deductions.get("night_navigation_hours"))
        set_optional_value(ws, f"D{58 + offset}", "document_onboard_hours", deductions.get("document_onboard_hours"))


def build_from_json(
    extraction: dict[str, Any],
    *,
    template: Path,
    output: Path,
    sheet_name: str | None,
    allow_missing: bool,
) -> dict[str, Any]:
    load_sections = normalize_sections(extraction.get("load"))
    discharge_sections = normalize_sections(extraction.get("discharge"))

    messages = []
    messages.extend(validate_events("LOAD", load_sections, LOAD_EVENTS, allow_missing=allow_missing))
    messages.extend(validate_events("DISCHARGE", discharge_sections, DISCHARGE_EVENTS, allow_missing=allow_missing))

    load_event_sets = [event_values(section, LOAD_EVENTS) for section in load_sections]
    discharge_event_sets = [event_values(section, DISCHARGE_EVENTS) for section in discharge_sections]
    load_starts, discharge_starts = save_workbook(
        template,
        output,
        load_event_sets,
        discharge_event_sets,
        sheet_name,
    )

    workbook = load_workbook(output)
    worksheet = workbook[sheet_name] if sheet_name else workbook.active
    metadata = extraction.get("metadata", {})
    if isinstance(metadata, dict):
        apply_metadata(worksheet, metadata)
    set_document_date(worksheet, row=document_date_row(discharge_starts))

    for section, block_start in zip(load_sections, load_starts):
        apply_load_section(worksheet, section, block_start)
    for section, block_start in zip(discharge_sections, discharge_starts):
        apply_discharge_section(worksheet, section, block_start)

    save_auto_recalc(workbook, output)
    return {
        "output": str(output),
        "load_block_starts": load_starts,
        "discharge_block_starts": discharge_starts,
        "messages": messages,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build a DEM claim workbook from extraction JSON.")
    parser.add_argument("--json", required=True, help="Extraction JSON path")
    parser.add_argument("--output", required=True, help="Output .xlsx path")
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE), help="Template workbook path")
    parser.add_argument("--sheet", default=None, help="Worksheet name; defaults to active sheet")
    parser.add_argument("--allow-missing", action="store_true", help="Write workbook even if required events are missing")
    parser.add_argument("--report", default=None, help="Optional validation/build report JSON path")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    extraction_path = Path(args.json).expanduser().resolve()
    template = ensure_template(Path(args.template).expanduser().resolve())
    output = Path(args.output).expanduser().resolve()
    extraction = json.loads(extraction_path.read_text(encoding="utf-8"))
    if not isinstance(extraction, dict):
        raise TypeError("Extraction JSON must be an object")

    report = build_from_json(
        extraction,
        template=template,
        output=output,
        sheet_name=args.sheet,
        allow_missing=args.allow_missing,
    )
    report_path = Path(args.report).expanduser().resolve() if args.report else output.with_suffix(".report.json")
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Saved workbook: {output}")
    print(f"Saved report: {report_path}")
    for message in report["messages"]:
        print(message)


if __name__ == "__main__":
    main()
