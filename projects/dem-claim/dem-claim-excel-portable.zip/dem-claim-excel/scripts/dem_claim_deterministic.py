#!/usr/bin/env python3
"""Run the deterministic DEM claim OCR workflow with portable skill defaults."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = SKILL_ROOT / "assets" / "DEM_CLAIM_TEMPLATE.xlsx"
WORKFLOW = SKILL_ROOT / "scripts" / "dem_claim_workflow_builder.py"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run deterministic DEM claim OCR extraction.")
    parser.add_argument("--load-source", nargs="*", default=[], help="Load SOF image/PDF files")
    parser.add_argument("--discharge-source", nargs="*", default=[], help="Discharge SOF image/PDF files")
    parser.add_argument("--output", required=True, help="Output .xlsx path")
    parser.add_argument("--debug-dir", default=None, help="Keep OCR crops/text in this folder")
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE), help="Template workbook path")
    parser.add_argument("--sheet", default=None, help="Worksheet name; defaults to active sheet")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    cmd = [
        sys.executable,
        str(WORKFLOW),
        "--template",
        str(Path(args.template).expanduser().resolve()),
        "--output",
        str(Path(args.output).expanduser().resolve()),
    ]
    if args.load_source:
        cmd.append("--load-source")
        cmd.extend(str(Path(source).expanduser().resolve()) for source in args.load_source)
    if args.discharge_source:
        cmd.append("--discharge-source")
        cmd.extend(str(Path(source).expanduser().resolve()) for source in args.discharge_source)
    if args.debug_dir:
        cmd.extend(["--debug-dir", str(Path(args.debug_dir).expanduser().resolve())])
    if args.sheet:
        cmd.extend(["--sheet", args.sheet])
    raise SystemExit(subprocess.run(cmd).returncode)


if __name__ == "__main__":
    main()
