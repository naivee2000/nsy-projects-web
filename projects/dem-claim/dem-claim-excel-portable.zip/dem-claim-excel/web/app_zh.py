#!/usr/bin/env python3
"""Chinese local DEM claim upload site for the portable skill.

Run this file when you want the Chinese UI. The default English app.py remains
unchanged.
"""

from __future__ import annotations

import json
import re
from typing import Annotated, Any

import app as base
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

app = FastAPI(title="装卸时间计算表Excel工具")

TEXT_REPLACEMENTS = [
    ("DEM Claim Excel", "装卸时间计算表Excel工具"),
    ("Local setup ready", "本地环境已就绪"),
    ("Setup needs attention", "设置需要处理"),
    ("Setup check failed", "设置检查失败"),
    ("Add Task", "添加任务"),
    ("Start All", "全部开始"),
    ("Download All", "全部下载"),
    ("Waiting for files.", "等待文件。"),
    ("Idle", "空闲"),
    ("Waiting", "等待中"),
    ("Not started", "未开始"),
    ("Ready.", "就绪。"),
    ("Files are selected for this task. Run it when the loading and discharge documents belong together.", "此任务的文件已选择。确认装港和卸港文件匹配后即可运行。"),
    ("Ready", "就绪"),
    ("Files selected", "已选择文件"),
    ("Ready to run.", "可以运行。"),
    ("Failed", "失败"),
    ("Needs attention", "需要处理"),
    ("Python OCR", "Python OCR"),
    ("Codex fallback", "Codex 识别"),
    ("Hybrid OCR", "混合识别"),
    ("Excel workbook is ready. Python OCR read", "Excel 工作簿已就绪。Python OCR 已读取"),
    ("Python OCR and Codex split the extraction.", "Python OCR 和 Codex 已分工完成识别。"),
    ("Python did not produce a per-file extraction report. Codex will read all uploaded sources.", "Python 未生成逐文件识别报告，Codex 将读取所有上传文件。"),
    ("Codex will read only", "Codex 将只读取"),
    ("unreadable source(s)", "个无法读取的文件"),
    ("Codex read", "Codex 已读取"),
    ("Python OCR read", "Python OCR 已读取"),
    ("Python read", "Python 已读取"),
    ("source(s)", "个文件"),
    ("Codex", "Codex"),
    ("Excel", "Excel"),
    ("Stopped before download was ready.", "下载准备好之前任务已停止。"),
    ("Waiting for updates.", "等待更新。"),
    ("Loading Files", "装港文件"),
    ("Discharge Files", "卸港文件"),
    ("No loading files", "无装港文件"),
    ("No discharge files", "无卸港文件"),
    ("Download", "下载"),
    ("Technical details", "技术详情"),
    ("Raw output from Python and Codex for troubleshooting.", "Python 和 Codex 的原始输出，用于排查问题。"),
    ("Remove", "删除"),
    ("Run Again", "重新运行"),
    ("Run Task", "开始任务"),
    ("Clear Files", "清除文件"),
    ("Uploading files...", "正在上传文件..."),
    ("Uploading this task's loading and discharge files.", "正在上传此任务的装港和卸港文件。"),
    ("Queued", "排队中"),
    ("Files received", "已收到文件"),
    ("Uploading", "上传中"),
    ("Sending this task's loading and discharge files to the local server.", "正在将此任务的装港和卸港文件发送到本地服务。"),
    ("Upload failed", "上传失败"),
    ("Python packages", "Python 包"),
    ("Tesseract", "Tesseract"),
    ("Codex CLI", "Codex CLI"),
    ("Codex login", "Codex 登录"),
    ("Setup needs attention:", "设置需要处理："),
    ("Setup check failed", "设置检查失败"),
    ("Checking", "检查中"),
    ("Codex reading", "Codex 读取中"),
    ("Preparing Codex", "准备 Codex"),
    ("Reading documents", "读取文件中"),
    ("Creating Excel", "生成 Excel"),
    ("Complete", "完成"),
    ("Not started", "未开始"),
    ("Checking with Python OCR", "使用 Python OCR 检查"),
    ("Python OCR completed", "Python OCR 已完成"),
    ("Python OCR could not read all fields", "Python OCR 未能读取全部字段"),
    ("Codex visual reading started", "Codex 视觉读取已开始"),
    ("Codex finished reading", "Codex 读取已完成"),
    ("Creating Excel workbook", "正在生成 Excel 工作簿"),
    ("Excel workbook ready", "Excel 工作簿已就绪"),
    ("Excel ready with review item", "Excel 已就绪但有需复核项目"),
    ("Download is available.", "可以下载。"),
    ("Job failed", "任务失败"),
    ("Job canceled", "任务已取消"),
    ("Task canceled.", "任务已取消。"),
    ("Job queued", "任务已排队"),
    ("Files uploaded. Waiting to start.", "文件已上传，等待开始。"),
    ("Job not found.", "找不到任务。"),
    ("Workbook is not ready.", "工作簿尚未准备好。"),
    ("No completed workbooks are ready to download.", "还没有可下载的已完成工作簿。"),
    ("At least one loading file is required.", "至少需要一个装港文件。"),
    ("At least one discharge file is required.", "至少需要一个卸港文件。"),
]

PASSTHROUGH_KEYS = {
    "job_id",
    "task_number",
    "status",
    "phase",
    "method",
    "state",
    "level",
    "field",
    "created_at",
    "updated_at",
    "download_ready",
    "report_path",
    "extraction_path",
    "load_files",
    "discharge_files",
    "timings",
    "log",
}

HTML_REPLACEMENTS = [
    ("<title>DEM Claim Excel</title>", "<title>装卸时间计算表Excel工具</title>"),
    ("<h1>DEM Claim Excel</h1>", "<h1>装卸时间计算表Excel工具</h1>"),
    (">Add Task<", ">添加任务<"),
    (">Start All<", ">全部开始<"),
    (">Download All<", ">全部下载<"),
    ('message: "Waiting for files."', 'message: "等待文件。"'),
    ('summary: "Waiting for files."', 'summary: "等待文件。"'),
    ('labels: { status: "Idle", phase: "Waiting", method: "Not started" }', 'labels: { status: "空闲", phase: "等待中", method: "未开始" }'),
    ('task.message = "Ready.";', 'task.message = "就绪。";'),
    (
        'task.summary = "Files are selected for this task. Run it when the loading and discharge documents belong together.";',
        'task.summary = "此任务的文件已选择。确认装港和卸港文件匹配后即可运行。";',
    ),
    ('task.labels = { status: "Ready", phase: "Waiting", method: "Not started" };', 'task.labels = { status: "就绪", phase: "等待中", method: "未开始" };'),
    ('{ level: "info", title: "Files selected", detail: "Ready to run.", time: "" }', '{ level: "info", title: "已选择文件", detail: "可以运行。", time: "" }'),
    ('task.labels = { status: "Failed", phase: "Needs attention", method: task.method === "Codex fallback" ? "Codex fallback" : "Not started" };', 'task.labels = { status: "失败", phase: "需要处理", method: task.method === "Codex fallback" ? "Codex 识别" : "未开始" };'),
    ('{ name: "Python OCR", state: "waiting", detail: "" }', '{ name: "Python OCR", state: "waiting", detail: "" }'),
    ('{ name: "Codex", state: "waiting", detail: "" }', '{ name: "Codex", state: "waiting", detail: "" }'),
    ('{ name: "Excel", state: "waiting", detail: "" }', '{ name: "Excel", state: "waiting", detail: "" }'),
    ('{ name: "Excel", state: "failed", detail: "Stopped before download was ready." }', '{ name: "Excel", state: "failed", detail: "下载准备好之前任务已停止。" }'),
    ('task.message = "Waiting for files.";', 'task.message = "等待文件。";'),
    ('task.summary = "Waiting for files.";', 'task.summary = "等待文件。";'),
    ('task.labels = { status: "Idle", phase: "Waiting", method: "Not started" };', 'task.labels = { status: "空闲", phase: "等待中", method: "未开始" };'),
    ('task.message || "Waiting for updates."', 'task.message || "等待更新。"'),
    ('phase: task.phase || "Waiting"', 'phase: task.phase || "等待中"'),
    ('<a class="download" href="/api/jobs/${task.jobId}/download?task=${encodeURIComponent(task.number)}">Download</a>', '<a class="download" href="/api/jobs/${task.jobId}/download?task=${encodeURIComponent(task.number)}">下载</a>'),
    ('<summary>Technical details</summary><p class="log-hint">Raw output from Python and Codex for troubleshooting.</p>', '<summary>技术详情</summary><p class="log-hint">Python 和 Codex 的原始输出，用于排查问题。</p>'),
    ('<h2>Task ${task.number}</h2>', '<h2>任务 ${task.number}</h2>'),
    (">Remove<", ">删除<"),
    ("<label>Loading Files</label>", "<label>装港文件</label>"),
    ('renderFiles(task.loadFiles, "No loading files")', 'renderFiles(task.loadFiles, "无装港文件")'),
    ("<label>Discharge Files</label>", "<label>卸港文件</label>"),
    ('renderFiles(task.dischargeFiles, "No discharge files")', 'renderFiles(task.dischargeFiles, "无卸港文件")'),
    ('${task.status === "completed" ? "Run Again" : "Run Task"}', '${task.status === "completed" ? "重新运行" : "开始任务"}'),
    (">Clear Files<", ">清除文件<"),
    ('`Start All (${runnable})`', '`全部开始 (${runnable})`'),
    ('"Start All"', '"全部开始"'),
    ('`Download All (${downloadable})`', '`全部下载 (${downloadable})`'),
    ('"Download All"', '"全部下载"'),
    ('task.message = "Uploading files...";', 'task.message = "正在上传文件...";'),
    ('task.summary = "Uploading this task\\\'s loading and discharge files.";', 'task.summary = "正在上传此任务的装港和卸港文件。";'),
    ('task.labels = { status: "Queued", phase: "Files received", method: "Not started" };', 'task.labels = { status: "排队中", phase: "已收到文件", method: "未开始" };'),
    ('title: "Uploading", detail: "Sending this task\\\'s loading and discharge files to the local server."', 'title: "上传中", detail: "正在将此任务的装港和卸港文件发送到本地服务。"'),
    ('throw new Error(body.detail || "Upload failed")', 'throw new Error(body.detail || "上传失败")'),
    ('setup.textContent = "Local setup ready";', 'setup.textContent = "本地环境已就绪";'),
    ('if (!data.packages_ok) missing.push("Python packages");', 'if (!data.packages_ok) missing.push("Python 包");'),
    ('if (!data.tesseract_ok) missing.push("Tesseract");', 'if (!data.tesseract_ok) missing.push("Tesseract");'),
    ('if (!data.codex_ok) missing.push("Codex CLI");', 'if (!data.codex_ok) missing.push("Codex CLI");'),
    ('if (!data.codex_auth_ok) missing.push("Codex login");', 'if (!data.codex_auth_ok) missing.push("Codex 登录");'),
    ('`Setup needs attention: ${missing.join(", ")}`', '`设置需要处理：${missing.join("、")}`'),
    ('setup.textContent = "Setup check failed";', 'setup.textContent = "设置检查失败";'),
]

ZH_STEPS_STYLE = """
    .steps {
      align-items: stretch;
    }
    .step {
      justify-items: center;
      text-align: center;
    }
    .step-top {
      justify-content: center;
      flex-direction: column;
      gap: 6px;
      text-align: center;
    }
    .step-name {
      width: min(100%, 96px);
      text-align: center;
      overflow-wrap: normal;
      word-break: keep-all;
    }
    .step-detail {
      text-align: center;
    }
"""


def translate_text(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    match = re.fullmatch(r"Workbook generated with (\d+) warning\(s\)\.", value)
    if match:
        return f"工作簿已生成，有 {match.group(1)} 个项目需要复核。"
    text = value
    for old, new in TEXT_REPLACEMENTS:
        text = text.replace(old, new)
    return text


def translate_payload(value: Any, key: str | None = None) -> Any:
    if key in PASSTHROUGH_KEYS:
        return value
    if key == "labels" and isinstance(value, dict):
        return {item_key: translate_text(item) for item_key, item in value.items()}
    if isinstance(value, dict):
        return {item_key: translate_payload(item, item_key) for item_key, item in value.items()}
    if isinstance(value, list):
        return [translate_payload(item, key) for item in value]
    return translate_text(value)


def translated_response(response: JSONResponse) -> JSONResponse:
    data = json.loads(response.body.decode("utf-8"))
    return JSONResponse(translate_payload(data), status_code=response.status_code)


def chinese_html() -> str:
    index_path = base.BASE_DIR / "static" / "index.html"
    html = index_path.read_text(encoding="utf-8") if index_path.exists() else base.HTML
    for old, new in HTML_REPLACEMENTS:
        html = html.replace(old, new)
    html = html.replace("</style>", f"{ZH_STEPS_STYLE}\n  </style>", 1)
    return html


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return chinese_html()


@app.get("/api/setup")
async def setup_status() -> JSONResponse:
    return translated_response(await base.setup_status())


@app.post("/api/jobs", status_code=202)
async def create_job(
    load_files: Annotated[list[UploadFile], File()],
    discharge_files: Annotated[list[UploadFile], File()],
    task_number: Annotated[str | None, Form()] = None,
) -> JSONResponse:
    return translated_response(await base.create_job(load_files, discharge_files, task_number))


@app.get("/api/jobs/download-all")
async def download_all_jobs(items: str = "") -> FileResponse:
    return await base.download_all_jobs(items)


@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str) -> JSONResponse:
    return translated_response(await base.delete_job(job_id))


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str) -> JSONResponse:
    return translated_response(await base.get_job(job_id))


@app.get("/api/jobs/{job_id}/download")
async def download_job(job_id: str, task: int | None = None) -> FileResponse:
    return await base.download_job(job_id, task)


if __name__ == "__main__":
    import os
    import uvicorn

    uvicorn.run("app_zh:app", host="127.0.0.1", port=int(os.environ.get("PORT", "8000")), reload=False)
