# DEM Claim Excel Web App

This local FastAPI app wraps the `dem-claim-excel` skill with a browser upload UI. The page starts with one task card and lets the user add more cards or start all ready cards at once, so multiple DEM claims can run at the same time without mixing loading/discharge documents between claims.

## Run

From the skill root:

```bash
python -m pip install -r scripts/requirements.txt
python scripts/dem_claim_setup_check.py
python web/app.py
```

Open http://127.0.0.1:8000.

## Flow

1. Upload loading files and discharge files in workbook order.
2. Each task card submits as its own job and produces its own workbook download.
3. The app runs deterministic Python OCR first.
4. If OCR misses required fields, the app renders PDFs to PNG when needed and calls local `codex exec` with the computer's saved Codex login.
5. Codex returns extraction JSON, and `scripts/dem_claim_from_json.py` builds the Excel file.
6. If the source leaves a required event blank, the web app retries the workbook build with warnings so the file can still be downloaded for review.

No `OPENAI_API_KEY` is required for the default fallback path. Codex fallback requires Codex CLI to be installed, logged in, connected, and within account usage limits on that computer.
