#!/usr/bin/env python3
"""Local DEM claim upload site with Python OCR and Codex fallback."""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import re
import shutil
import sys
import textwrap
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any
from zipfile import ZIP_DEFLATED, ZipFile

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.background import BackgroundTask

try:
    import fitz  # PyMuPDF
except ModuleNotFoundError:  # pragma: no cover - setup endpoint reports this clearly
    fitz = None

try:
    from PIL import Image
except ModuleNotFoundError:  # pragma: no cover - setup endpoint reports this clearly
    Image = None


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_SKILL_ROOT = BASE_DIR.parent
SKILL_ROOT = Path(os.environ.get("DEM_SKILL_ROOT", DEFAULT_SKILL_ROOT)).expanduser().resolve()
CODEX_BIN = os.environ.get("CODEX_BIN") or shutil.which("codex") or "/Applications/Codex.app/Contents/Resources/codex"
CODEX_FALLBACK_MODEL = os.environ.get("CODEX_FALLBACK_MODEL", "gpt-5.5")
CODEX_FALLBACK_REASONING_EFFORT = os.environ.get("CODEX_FALLBACK_REASONING_EFFORT", "medium")
CODEX_FALLBACK_CLEAN_CONFIG = os.environ.get("CODEX_FALLBACK_CLEAN_CONFIG", "1").lower() not in {"0", "false", "no"}
JOB_ROOT = Path(os.environ.get("DEM_JOB_ROOT", SKILL_ROOT / "web_outputs")).expanduser().resolve()
ALLOWED_SUFFIXES = {".png", ".jpg", ".jpeg", ".pdf", ".tif", ".tiff"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg"}
CONVERTIBLE_IMAGE_SUFFIXES = {".tif", ".tiff"}
REQUIRED_LOAD_EVENTS = ("nor_tendered", "all_fast", "hose_on", "load_commence", "load_complete", "hose_off")
REQUIRED_DISCHARGE_EVENTS = (
    "nor_tendered",
    "anchor_up",
    "all_fast",
    "hose_on",
    "disch_commence",
    "disch_complete",
    "hose_off",
)

app = FastAPI(title="DEM Claim Excel")
jobs: dict[str, dict[str, Any]] = {}
job_tasks: dict[str, asyncio.Task[Any]] = {}

STATUS_LABELS = {
    "queued": "Queued",
    "processing": "Checking",
    "fallback": "Codex reading",
    "completed": "Ready",
    "failed": "Failed",
}

PHASE_LABELS = {
    "waiting": "Waiting",
    "queued": "Files received",
    "python-ocr": "Python OCR",
    "codex-fallback": "Preparing Codex",
    "codex-reading": "Reading documents",
    "excel-build": "Creating Excel",
    "complete": "Complete",
    "failed": "Needs attention",
}

METHOD_LABELS = {
    "pending": "Not started",
    "Python OCR": "Python OCR",
    "Codex fallback": "Codex fallback",
    "Hybrid OCR": "Hybrid OCR",
}


CODEX_EXTRACTION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "metadata": {
            "type": "object",
            "properties": {
                "charterer": {"type": ["string", "null"]},
                "charterer_ref": {"type": ["string", "null"]},
                "owner": {"type": ["string", "null"]},
                "owner_ref": {"type": ["string", "null"]},
                "broker": {"type": ["string", "null"]},
                "vessel": {"type": ["string", "null"]},
                "cp_date": {"type": ["string", "null"]},
                "demurrage_rate": {"type": ["number", "null"]},
                "total_cargo_quantity": {"type": ["number", "null"]},
                "currency": {"type": ["string", "null"]},
                "laycan_start": {"type": ["string", "null"]},
                "laycan_end": {"type": ["string", "null"]},
                "doc_date": {"type": ["string", "null"]},
            },
            "required": [
                "charterer",
                "charterer_ref",
                "owner",
                "owner_ref",
                "broker",
                "vessel",
                "cp_date",
                "demurrage_rate",
                "total_cargo_quantity",
                "currency",
                "laycan_start",
                "laycan_end",
                "doc_date",
            ],
            "additionalProperties": False,
        },
        "load": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "port": {"type": ["string", "null"]},
                    "berth": {"type": ["string", "null"]},
                    "terminal": {"type": ["string", "null"]},
                    "allowed_hours": {"type": ["number", "null"]},
                    "document_onboard_hours": {"type": ["number", "null"]},
                    "events": {
                        "type": "object",
                        "properties": {
                            "nor_tendered": {"type": ["string", "null"]},
                            "anchor_up": {"type": ["string", "null"]},
                            "all_fast": {"type": ["string", "null"]},
                            "hose_on": {"type": ["string", "null"]},
                            "load_commence": {"type": ["string", "null"]},
                            "load_complete": {"type": ["string", "null"]},
                            "hose_off": {"type": ["string", "null"]},
                        },
                        "required": [
                            "nor_tendered",
                            "anchor_up",
                            "all_fast",
                            "hose_on",
                            "load_commence",
                            "load_complete",
                            "hose_off",
                        ],
                        "additionalProperties": False,
                    },
                },
                "required": ["port", "berth", "terminal", "allowed_hours", "document_onboard_hours", "events"],
                "additionalProperties": False,
            },
        },
        "discharge": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "port": {"type": ["string", "null"]},
                    "berth": {"type": ["string", "null"]},
                    "quantity": {"type": ["number", "null"]},
                    "rate": {"type": ["number", "null"]},
                    "allowed_hours": {"type": ["number", "null"]},
                    "events": {
                        "type": "object",
                        "properties": {
                            "nor_tendered": {"type": ["string", "null"]},
                            "anchor_up": {"type": ["string", "null"]},
                            "all_fast": {"type": ["string", "null"]},
                            "hose_on": {"type": ["string", "null"]},
                            "disch_commence": {"type": ["string", "null"]},
                            "disch_complete": {"type": ["string", "null"]},
                            "hose_off": {"type": ["string", "null"]},
                        },
                        "required": [
                            "nor_tendered",
                            "anchor_up",
                            "all_fast",
                            "hose_on",
                            "disch_commence",
                            "disch_complete",
                            "hose_off",
                        ],
                        "additionalProperties": False,
                    },
                    "deductions": {
                        "type": "object",
                        "properties": {
                            "shifting_hours": {"type": ["number", "null"]},
                            "rate_difference_hours": {"type": ["number", "null"]},
                            "night_navigation_hours": {"type": ["number", "null"]},
                            "document_onboard_hours": {"type": ["number", "null"]},
                        },
                        "required": [
                            "shifting_hours",
                            "rate_difference_hours",
                            "night_navigation_hours",
                            "document_onboard_hours",
                        ],
                        "additionalProperties": False,
                    },
                },
                "required": ["port", "berth", "quantity", "rate", "allowed_hours", "events", "deductions"],
                "additionalProperties": False,
            },
        },
        "confidence_notes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "field": {"type": "string"},
                    "note": {"type": "string"},
                },
                "required": ["field", "note"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["metadata", "load", "discharge", "confidence_notes"],
    "additionalProperties": False,
}


HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DEM Claim Excel</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f5f7fb;
      --panel: #ffffff;
      --ink: #152033;
      --muted: #667085;
      --line: #d9e0ea;
      --blue: #2166d5;
      --green: #087f5b;
      --amber: #a15c00;
      --red: #b42318;
      --shadow: 0 18px 48px rgba(26, 39, 68, 0.12);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: var(--bg);
      color: var(--ink);
      letter-spacing: 0;
    }
    main {
      width: min(1120px, calc(100vw - 32px));
      margin: 0 auto;
      padding: 28px 0 40px;
    }
    header {
      display: flex;
      align-items: end;
      justify-content: space-between;
      gap: 20px;
      margin-bottom: 20px;
    }
    h1 {
      margin: 0;
      font-size: clamp(28px, 4vw, 42px);
      line-height: 1.05;
      letter-spacing: 0;
    }
    .status-pill {
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 8px 12px;
      background: #fff;
      color: var(--muted);
      white-space: nowrap;
      font-size: 14px;
    }
    .shell {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      box-shadow: var(--shadow);
      overflow: hidden;
    }
    form {
      padding: 20px;
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
    }
    .drop {
      min-height: 250px;
      border: 1px dashed #a8b3c4;
      border-radius: 8px;
      background: #fbfcff;
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .drop:focus-within,
    .drop.dragging {
      border-color: var(--blue);
      box-shadow: 0 0 0 3px rgba(33, 102, 213, 0.12);
    }
    label {
      font-weight: 700;
      font-size: 18px;
    }
    input[type=file] {
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 10px;
      background: #fff;
      color: var(--ink);
    }
    .files {
      min-height: 132px;
      margin: 0;
      padding: 0;
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .files li {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 8px 10px;
      background: #fff;
      font-size: 14px;
    }
    .empty {
      color: var(--muted);
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 12px;
      background: #fff;
      font-size: 14px;
    }
    .actions {
      grid-column: 1 / -1;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      padding-top: 4px;
    }
    button, .download {
      min-height: 42px;
      border: 0;
      border-radius: 6px;
      padding: 0 16px;
      background: var(--blue);
      color: #fff;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    button:disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }
    .progress {
      border-top: 1px solid var(--line);
      padding: 18px 20px 20px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(280px, 420px);
      gap: 16px;
      background: #fbfcff;
    }
    .meter {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #fff;
      padding: 14px;
    }
    .meter h2, .log h2 {
      margin: 0 0 10px;
      font-size: 16px;
      letter-spacing: 0;
    }
    .state {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-bottom: 12px;
    }
    .tag {
      border-radius: 999px;
      padding: 6px 10px;
      background: #eef4ff;
      color: #194185;
      font-size: 13px;
      font-weight: 700;
    }
    .tag.ok { background: #dcfae6; color: var(--green); }
    .tag.warn { background: #fff2cc; color: var(--amber); }
    .tag.fail { background: #fee4e2; color: var(--red); }
    .message {
      margin: 0;
      color: var(--muted);
      line-height: 1.5;
      overflow-wrap: anywhere;
    }
    .log {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #101828;
      color: #e6edf7;
      padding: 14px;
      min-height: 200px;
      max-height: 360px;
      overflow: auto;
    }
    pre {
      margin: 0;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      font: 12px/1.45 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    }
    @media (max-width: 760px) {
      header, .actions { align-items: stretch; flex-direction: column; }
      form, .progress { grid-template-columns: 1fr; }
      .status-pill { white-space: normal; }
    }
  </style>
</head>
<body>
  <main>
    <header>
      <h1>DEM Claim Excel</h1>
      <div id="setup" class="status-pill">Checking local setup...</div>
    </header>
    <section class="shell">
      <form id="uploadForm">
        <div class="drop" data-input="loadFiles">
          <label for="loadFiles">Loading Files</label>
          <input id="loadFiles" name="load_files" type="file" accept=".png,.jpg,.jpeg,.pdf,.tif,.tiff" multiple required>
          <ul id="loadList" class="files"><li class="empty">No loading files selected</li></ul>
        </div>
        <div class="drop" data-input="dischargeFiles">
          <label for="dischargeFiles">Discharge Files</label>
          <input id="dischargeFiles" name="discharge_files" type="file" accept=".png,.jpg,.jpeg,.pdf,.tif,.tiff" multiple required>
          <ul id="dischargeList" class="files"><li class="empty">No discharge files selected</li></ul>
        </div>
        <div class="actions">
          <p class="message" id="hint">Python OCR runs first. Codex fallback is used only when required fields are missing.</p>
          <button id="submitBtn" type="submit">Generate Excel</button>
        </div>
      </form>
      <div class="progress">
        <div class="meter">
          <h2>Job</h2>
          <div id="state" class="state">
            <span class="tag">Idle</span>
          </div>
          <p id="message" class="message">Upload one or more files on each side.</p>
          <div id="downloadSlot" style="margin-top:14px;"></div>
        </div>
        <div class="log">
          <h2>Log</h2>
          <pre id="logText"></pre>
        </div>
      </div>
    </section>
  </main>
  <script>
    const form = document.getElementById("uploadForm");
    const loadFiles = document.getElementById("loadFiles");
    const dischargeFiles = document.getElementById("dischargeFiles");
    const submitBtn = document.getElementById("submitBtn");
    const setup = document.getElementById("setup");
    const state = document.getElementById("state");
    const message = document.getElementById("message");
    const logText = document.getElementById("logText");
    const downloadSlot = document.getElementById("downloadSlot");
    let pollTimer = null;

    function renderFileList(input, targetId, emptyText) {
      const list = document.getElementById(targetId);
      list.innerHTML = "";
      const files = Array.from(input.files || []);
      if (!files.length) {
        const item = document.createElement("li");
        item.className = "empty";
        item.textContent = emptyText;
        list.appendChild(item);
        return;
      }
      files.forEach((file, index) => {
        const item = document.createElement("li");
        const name = document.createElement("span");
        const size = document.createElement("span");
        name.textContent = `${index + 1}. ${file.name}`;
        size.textContent = `${Math.ceil(file.size / 1024)} KB`;
        item.append(name, size);
        list.appendChild(item);
      });
    }

    function setTags(job) {
      const status = job.status || "idle";
      const method = job.method || "pending";
      const phase = job.phase || "waiting";
      const statusClass = status === "completed" ? "ok" : status === "failed" ? "fail" : status === "fallback" ? "warn" : "";
      state.innerHTML = `
        <span class="tag ${statusClass}">${status}</span>
        <span class="tag">${phase}</span>
        <span class="tag">${method}</span>
      `;
    }

    async function checkSetup() {
      try {
        const res = await fetch("/api/setup");
        const data = await res.json();
        const ok = data.skill_root_ok && data.codex_ok && data.codex_auth_ok && data.tesseract_ok && data.packages_ok;
        setup.textContent = ok ? "Local setup ready" : "Setup needs attention";
        setup.style.color = ok ? "var(--green)" : "var(--amber)";
      } catch (error) {
        setup.textContent = "Setup check failed";
        setup.style.color = "var(--red)";
      }
    }

    async function poll(jobId) {
      const res = await fetch(`/api/jobs/${jobId}`);
      const job = await res.json();
      setTags(job);
      message.textContent = job.message || "";
      logText.textContent = job.log || "";
      if (job.status === "completed") {
        submitBtn.disabled = false;
        downloadSlot.innerHTML = `<a class="download" href="/api/jobs/${jobId}/download">Download Excel</a>`;
        clearInterval(pollTimer);
      } else if (job.status === "failed") {
        submitBtn.disabled = false;
        downloadSlot.innerHTML = "";
        clearInterval(pollTimer);
      }
    }

    loadFiles.addEventListener("change", () => renderFileList(loadFiles, "loadList", "No loading files selected"));
    dischargeFiles.addEventListener("change", () => renderFileList(dischargeFiles, "dischargeList", "No discharge files selected"));

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      downloadSlot.innerHTML = "";
      submitBtn.disabled = true;
      message.textContent = "Uploading files...";
      logText.textContent = "";
      const data = new FormData();
      Array.from(loadFiles.files).forEach(file => data.append("load_files", file));
      Array.from(dischargeFiles.files).forEach(file => data.append("discharge_files", file));
      try {
        const res = await fetch("/api/jobs", { method: "POST", body: data });
        const body = await res.json();
        if (!res.ok) throw new Error(body.detail || "Upload failed");
        setTags(body);
        message.textContent = body.message || "Processing...";
        pollTimer = setInterval(() => poll(body.job_id), 1600);
        await poll(body.job_id);
      } catch (error) {
        submitBtn.disabled = false;
        state.innerHTML = '<span class="tag fail">failed</span>';
        message.textContent = error.message;
      }
    });

    document.querySelectorAll(".drop").forEach(drop => {
      const input = document.getElementById(drop.dataset.input);
      drop.addEventListener("dragover", event => {
        event.preventDefault();
        drop.classList.add("dragging");
      });
      drop.addEventListener("dragleave", () => drop.classList.remove("dragging"));
      drop.addEventListener("drop", event => {
        event.preventDefault();
        drop.classList.remove("dragging");
        input.files = event.dataTransfer.files;
        input.dispatchEvent(new Event("change"));
      });
    });

    checkSetup();
  </script>
</body>
</html>
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def public_job(job: dict[str, Any]) -> dict[str, Any]:
    return {
        "job_id": job["job_id"],
        "task_number": job.get("task_number"),
        "status": job["status"],
        "phase": job["phase"],
        "method": job["method"],
        "labels": {
            "status": STATUS_LABELS.get(job["status"], job["status"]),
            "phase": PHASE_LABELS.get(job["phase"], job["phase"]),
            "method": METHOD_LABELS.get(job["method"], job["method"]),
        },
        "message": job["message"],
        "summary": job_summary(job),
        "warnings": job.get("warnings", []),
        "steps": job_steps(job),
        "timings": job.get("timings", {}),
        "created_at": job["created_at"],
        "updated_at": job["updated_at"],
        "load_files": [path.name for path in job["load_files"]],
        "discharge_files": [path.name for path in job["discharge_files"]],
        "download_ready": bool(job.get("output_path") and Path(job["output_path"]).exists()),
        "report_path": str(job.get("report_path") or ""),
        "extraction_path": str(job.get("extraction_path") or ""),
        "events": job.get("events", [])[-30:],
        "log": job.get("log", "")[-12000:],
    }


def normalize_task_number(value: Any) -> int | None:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def task_excel_filename(task_number: Any = None) -> str:
    number = normalize_task_number(task_number)
    if number is None:
        return "task_excel.xlsx"
    return f"task_{number}_excel.xlsx"


def parse_download_items(items: str) -> list[tuple[str, int | None]]:
    parsed: list[tuple[str, int | None]] = []
    for item in (items or "").split(","):
        clean = item.strip()
        if not clean:
            continue
        if ":" in clean:
            job_id, task_number = clean.split(":", 1)
        else:
            job_id, task_number = clean, None
        if re.fullmatch(r"[0-9a-f]{12}", job_id):
            parsed.append((job_id, normalize_task_number(task_number)))
    return parsed


def unique_archive_name(name: str, used: set[str]) -> str:
    if name not in used:
        used.add(name)
        return name
    path = Path(name)
    for index in range(2, 1000):
        candidate = f"{path.stem}_{index}{path.suffix}"
        if candidate not in used:
            used.add(candidate)
            return candidate
    raise RuntimeError(f"Could not create a unique filename for {name}")


def update_job(job: dict[str, Any], **changes: Any) -> None:
    job.update(changes)
    job["updated_at"] = now_iso()


def append_log(job: dict[str, Any], title: str, text: str) -> None:
    clean = text.strip()
    if not clean:
        return
    previous = job.get("log", "")
    job["log"] = (previous + f"\n\n[{title}]\n{clean}").strip()
    job["updated_at"] = now_iso()


def add_event(job: dict[str, Any], level: str, title: str, detail: str = "") -> None:
    events = job.setdefault("events", [])
    events.append(
        {
            "time": now_iso(),
            "level": level,
            "title": title,
            "detail": detail,
        }
    )
    job["updated_at"] = now_iso()


def format_seconds(seconds: float | int | None) -> str:
    if seconds is None:
        return ""
    seconds = float(seconds)
    if seconds < 60:
        return f"{seconds:.1f} seconds"
    minutes = int(seconds // 60)
    remaining = int(round(seconds % 60))
    return f"{minutes} min {remaining:02d} sec"


def friendly_missing_fields(text: str) -> str:
    fields = [field.strip().replace("_", " ").upper() for field in re.split(r",\s*", text) if field.strip()]
    return ", ".join(fields) if fields else text.strip()


def friendly_warning(raw: str) -> dict[str, str]:
    text = str(raw).strip()
    clean = re.sub(r"^WARNING:\s*", "", text, flags=re.IGNORECASE)
    match = re.search(r"^(LOAD|DISCHARGE)\s+(\d+)\s+missing required events:\s*(.+)$", clean, flags=re.IGNORECASE)
    if match:
        section = match.group(1).title()
        number = match.group(2)
        missing = friendly_missing_fields(match.group(3))
        return {
            "title": f"{section} {number}: review missing event",
            "detail": f"Missing required event: {missing}. The workbook was still created, but this field should be checked before sending the claim.",
            "raw": text,
        }
    match = re.search(
        r"^(LOAD|DISCHARGE)\s+(\d+)\s+event\s+(.+?)\s+is earlier than the prior extracted event$",
        clean,
        flags=re.IGNORECASE,
    )
    if match:
        section = match.group(1).title()
        number = match.group(2)
        event = match.group(3).strip()
        return {
            "title": f"{section} {number}: check event order",
            "detail": f"{event} appears earlier than the prior event. Review the source document before using the workbook.",
            "raw": text,
        }
    return {
        "title": "Review warning",
        "detail": clean or text,
        "raw": text,
    }


def extraction_missing_required(extraction: dict[str, Any]) -> list[str]:
    missing: list[str] = []
    for index, section in enumerate(extraction.get("load") or [], start=1):
        events = section.get("events", {}) if isinstance(section, dict) else {}
        for key in REQUIRED_LOAD_EVENTS:
            if not events.get(key):
                missing.append(f"LOAD {index} {key.replace('_', ' ').upper()}")
    for index, section in enumerate(extraction.get("discharge") or [], start=1):
        events = section.get("events", {}) if isinstance(section, dict) else {}
        for key in REQUIRED_DISCHARGE_EVENTS:
            if not events.get(key):
                missing.append(f"DISCHARGE {index} {key.replace('_', ' ').upper()}")
    return missing


def partial_records(partial: dict[str, Any], section: str | None = None) -> list[dict[str, Any]]:
    sections = (section,) if section else ("load", "discharge")
    records: list[dict[str, Any]] = []
    for name in sections:
        for record in partial.get(name) or []:
            if isinstance(record, dict):
                records.append(record)
    return records


def records_needing_codex(partial: dict[str, Any]) -> list[dict[str, Any]]:
    return [record for record in partial_records(partial) if not record.get("ok")]


def clean_python_section(record: dict[str, Any]) -> dict[str, Any]:
    item = {
        key: value
        for key, value in record.items()
        if key not in {"ok", "missing", "error", "source_path", "section", "index"}
    }
    item["method"] = "python_ocr"
    return item


def empty_codex_section(section: str, record: dict[str, Any]) -> dict[str, Any]:
    base: dict[str, Any]
    if section == "load":
        base = {
            "port": None,
            "berth": None,
            "terminal": None,
            "allowed_hours": None,
            "document_onboard_hours": None,
            "events": {},
        }
    else:
        base = {
            "port": None,
            "berth": None,
            "quantity": None,
            "rate": None,
            "allowed_hours": None,
            "events": {},
            "deductions": {
                "shifting_hours": None,
                "rate_difference_hours": None,
                "night_navigation_hours": None,
                "document_onboard_hours": None,
            },
        }
    base.update(
        {
            "source": record.get("source"),
            "original_index": record.get("index"),
            "method": "codex_missing",
        }
    )
    return base


def normalize_confidence_notes(value: Any) -> list[dict[str, str]]:
    if isinstance(value, list):
        return [
            {"field": str(item.get("field", "")), "note": str(item.get("note", ""))}
            for item in value
            if isinstance(item, dict)
        ]
    if isinstance(value, dict):
        return [{"field": str(field), "note": str(note)} for field, note in value.items()]
    return []


def merge_hybrid_extraction(partial: dict[str, Any], codex: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {
        "metadata": codex.get("metadata") if isinstance(codex.get("metadata"), dict) else partial.get("metadata", {}),
        "load": [],
        "discharge": [],
        "confidence_notes": normalize_confidence_notes(codex.get("confidence_notes")),
    }
    for section in ("load", "discharge"):
        codex_sections = [item for item in codex.get(section) or [] if isinstance(item, dict)]
        codex_index = 0
        for record in partial.get(section) or []:
            if not isinstance(record, dict):
                continue
            if record.get("ok"):
                merged[section].append(clean_python_section(record))
                continue
            if codex_index < len(codex_sections):
                item = dict(codex_sections[codex_index])
                codex_index += 1
            else:
                item = empty_codex_section(section, record)
                merged["confidence_notes"].append(
                    {
                        "field": f"{section}.{record.get('index')}",
                        "note": "Codex did not return a section for this source; workbook was built with blanks for review.",
                    }
                )
            item.setdefault("source", record.get("source"))
            item.setdefault("original_index", record.get("index"))
            item["method"] = "codex"
            merged[section].append(item)
        if codex_index < len(codex_sections):
            for extra in codex_sections[codex_index:]:
                item = dict(extra)
                item["method"] = "codex_extra"
                merged[section].append(item)
                merged["confidence_notes"].append(
                    {
                        "field": section,
                        "note": "Codex returned an extra section beyond the files marked unreadable by Python.",
                    }
                )
    return merged


def job_summary(job: dict[str, Any]) -> str:
    status = job.get("status")
    phase = job.get("phase")
    method = job.get("method")
    warnings = job.get("warnings") or []
    timings = job.get("timings", {})

    if status == "queued":
        return "Files are uploaded and waiting to start."
    if phase == "python-ocr":
        return "Python is checking whether the required dates and times can be read automatically."
    if phase in {"codex-fallback", "codex-reading"}:
        return "Codex is visually reading the documents because Python OCR could not read every required field."
    if phase == "excel-build":
        return "The extracted values are being placed into the Excel template."
    if status == "completed" and method == "Python OCR":
        duration = format_seconds(timings.get("python_ocr"))
        return f"Excel is ready. Python OCR completed the task{f' in {duration}' if duration else ''}."
    if status == "completed" and method == "Hybrid OCR":
        summary = job.get("hybrid_summary") or {}
        python_count = summary.get("python_complete")
        codex_count = summary.get("needs_codex")
        if python_count is not None and codex_count is not None:
            return f"Excel is ready. Python OCR handled {python_count} source(s); Codex read {codex_count} source(s)."
        return "Excel is ready. Python OCR and Codex split the extraction."
    if status == "completed":
        codex_duration = format_seconds(timings.get("codex_fallback"))
        if warnings:
            return f"Excel is ready with {len(warnings)} item(s) to review. Codex handled the visual reading{f' in {codex_duration}' if codex_duration else ''}."
        return f"Excel is ready. Codex handled the visual reading{f' in {codex_duration}' if codex_duration else ''}."
    if status == "failed":
        return "This task stopped before an Excel file could be created. Check the message and technical details below."
    return job.get("message", "Waiting for updates.")


def job_steps(job: dict[str, Any]) -> list[dict[str, str]]:
    status = job.get("status")
    phase = job.get("phase")
    method = job.get("method")

    def step(name: str, state: str, detail: str = "") -> dict[str, str]:
        return {"name": name, "state": state, "detail": detail}

    if status == "failed":
        return [
            step("Files", "done"),
            step("Python OCR", "done" if phase != "queued" else "waiting"),
            step("Codex", "done" if method in {"Codex fallback", "Hybrid OCR"} else "skipped"),
            step("Excel", "failed", "Stopped before download was ready."),
        ]

    python_state = "waiting"
    codex_state = "waiting"
    excel_state = "waiting"

    if status == "queued":
        python_state = "waiting"
    elif phase == "python-ocr":
        python_state = "current"
    elif status in {"fallback", "completed"}:
        python_state = "done"

    if method == "Python OCR" and status == "completed":
        codex_state = "skipped"
    elif phase in {"codex-fallback", "codex-reading"}:
        codex_state = "current"
    elif phase == "excel-build" or (status == "completed" and method in {"Codex fallback", "Hybrid OCR"}):
        codex_state = "done"

    if phase == "excel-build":
        excel_state = "current"
    elif status == "completed":
        excel_state = "warning" if job.get("warnings") else "done"

    return [
        step("Files", "done", f"{len(job['load_files'])} loading, {len(job['discharge_files'])} discharge."),
        step("Python OCR", python_state),
        step("Codex", codex_state),
        step("Excel", excel_state),
    ]


def deterministic_failure_message(stdout: str, stderr: str) -> str:
    text = f"{stdout}\n{stderr}"
    source_matches = re.findall(r"^Source:\s*(.+)$", stdout, flags=re.MULTILINE)
    source = source_matches[-1] if source_matches else "one uploaded source"
    match = re.search(r"OCR could not find required ([A-Z]+) events:\s*(.+)", text)
    if not match:
        return "Python could not read every required field. Codex is reading the documents now."
    section = match.group(1).title()
    missing = friendly_missing_fields(match.group(2))
    source_name = Path(source).name
    return f"Python could not read required {section} fields from {source_name}. Missing: {missing}. Codex is reading the documents now."


def workbook_failure_message(stdout: str, stderr: str, code: int) -> str:
    text = f"{stdout}\n{stderr}"
    match = re.search(r"ValueError:\s*(.+missing required events:\s*.+)", text)
    if match:
        return f"Codex returned JSON, but the workbook was not built because {match.group(1)}"
    tail = text.strip()[-1200:] if text.strip() else "No workbook error detail was returned."
    return f"Workbook build from Codex JSON failed with exit code {code}. {tail}"


def safe_filename(name: str, index: int) -> str:
    suffix = Path(name).suffix.lower()
    stem = Path(name).stem
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-") or "upload"
    return f"{index:02d}_{stem}{suffix}"


async def save_uploads(job_dir: Path, section: str, uploads: list[UploadFile]) -> list[Path]:
    target_dir = job_dir / "uploads" / section
    target_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    for index, upload in enumerate(uploads, start=1):
        suffix = Path(upload.filename or "").suffix.lower()
        if suffix not in ALLOWED_SUFFIXES:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {upload.filename}")
        path = target_dir / safe_filename(upload.filename or f"{section}_{index}{suffix}", index)
        content = await upload.read()
        if not content:
            raise HTTPException(status_code=400, detail=f"Empty upload: {upload.filename}")
        path.write_bytes(content)
        saved.append(path)
    return saved


async def run_command(
    cmd: list[str],
    *,
    cwd: Path,
    timeout: int,
    job: dict[str, Any] | None = None,
) -> tuple[int, str, str]:
    env = os.environ.copy()
    env.setdefault("TERM", "xterm-256color")
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=str(cwd),
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    if job is not None:
        job["current_process"] = proc
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        if proc.returncode is None:
            proc.kill()
        await proc.wait()
        return 124, "", f"Command timed out after {timeout} seconds"
    except asyncio.CancelledError:
        if proc.returncode is None:
            proc.terminate()
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(proc.wait(), timeout=3)
        if proc.returncode is None:
            proc.kill()
            await proc.wait()
        raise
    finally:
        if job is not None and job.get("current_process") is proc:
            job.pop("current_process", None)
    return (
        proc.returncode or 0,
        stdout.decode("utf-8", errors="replace"),
        stderr.decode("utf-8", errors="replace"),
    )


def check_paths() -> None:
    if not SKILL_ROOT.exists():
        raise RuntimeError(f"DEM skill root does not exist: {SKILL_ROOT}")
    partial = SKILL_ROOT / "scripts" / "dem_claim_extract_partial.py"
    from_json = SKILL_ROOT / "scripts" / "dem_claim_from_json.py"
    if not partial.exists() or not from_json.exists():
        raise RuntimeError(f"DEM skill scripts are missing under: {SKILL_ROOT}")
    if not Path(CODEX_BIN).exists() and not shutil.which(CODEX_BIN):
        raise RuntimeError(f"Codex CLI was not found: {CODEX_BIN}")


async def build_workbook_from_extraction(
    job: dict[str, Any],
    extraction: dict[str, Any],
    extraction_path: Path,
    *,
    method: str,
    ready_message: str,
) -> None:
    output = Path(job["job_dir"]) / "dem_claim.xlsx"
    report_path = Path(job["job_dir"]) / "dem_claim.report.json"
    cmd = [
        sys.executable,
        str(SKILL_ROOT / "scripts" / "dem_claim_from_json.py"),
        "--json",
        str(extraction_path),
        "--output",
        str(output),
        "--report",
        str(report_path),
        "--allow-missing",
    ]
    missing_required = extraction_missing_required(extraction)
    if missing_required:
        add_event(
            job,
            "warn",
            "Required field needs review",
            "A required event appears blank or unreadable in the source. The workbook will still be created with a warning.",
        )

    update_job(job, phase="excel-build", message="Creating the Excel workbook from the extracted values...")
    add_event(job, "info", "Creating Excel workbook", "Filling the Excel template with the extracted dates and times.")
    build_started = time.perf_counter()
    code, stdout, stderr = await run_command(cmd, cwd=SKILL_ROOT, timeout=180, job=job)
    build_seconds = time.perf_counter() - build_started
    job.setdefault("timings", {})["excel_build"] = round(build_seconds, 1)
    append_log(job, "JSON workbook stdout", stdout)
    append_log(job, "JSON workbook stderr", stderr)
    if code != 0 or not output.exists():
        raise RuntimeError(workbook_failure_message(stdout, stderr, code))

    message = ready_message
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
        warnings = [item for item in report.get("messages", []) if str(item).startswith("WARNING")]
        job["warnings"] = [friendly_warning(item) for item in warnings]
        if warnings:
            message = f"Excel workbook is ready with {len(warnings)} item(s) to review."
            review_text = " ".join(item["detail"] for item in job["warnings"])
            add_event(job, "warn", "Excel ready with review item", f"{review_text} Build took {format_seconds(build_seconds)}.")
        else:
            add_event(job, "ok", "Excel workbook ready", f"Download is available. Build took {format_seconds(build_seconds)}.")
    except Exception:
        add_event(job, "ok", "Excel workbook ready", f"Download is available. Build took {format_seconds(build_seconds)}.")

    update_job(
        job,
        status="completed",
        phase="complete",
        method=method,
        message=message,
        output_path=str(output),
        extraction_path=str(extraction_path),
        report_path=str(report_path),
    )


async def run_deterministic(job: dict[str, Any]) -> bool:
    job_dir = Path(job["job_dir"])
    debug_dir = Path(job["job_dir"]) / "debug_ocr"
    partial_path = job_dir / "python_partial_extraction.json"
    cmd = [
        sys.executable,
        str(SKILL_ROOT / "scripts" / "dem_claim_extract_partial.py"),
        "--json-output",
        str(partial_path),
        "--debug-dir",
        str(debug_dir),
    ]
    if job["load_files"]:
        cmd.append("--load-source")
        cmd.extend(str(path) for path in job["load_files"])
    if job["discharge_files"]:
        cmd.append("--discharge-source")
        cmd.extend(str(path) for path in job["discharge_files"])

    update_job(
        job,
        status="processing",
        phase="python-ocr",
        method="Python OCR",
        message="Checking the uploaded files with Python OCR...",
    )
    add_event(
        job,
        "info",
        "Checking with Python OCR",
        f"Reading {len(job['load_files'])} loading file(s) and {len(job['discharge_files'])} discharge file(s).",
    )
    ocr_started = time.perf_counter()
    code, stdout, stderr = await run_command(cmd, cwd=SKILL_ROOT, timeout=300, job=job)
    ocr_seconds = time.perf_counter() - ocr_started
    job.setdefault("timings", {})["python_ocr"] = round(ocr_seconds, 1)
    append_log(job, "Python OCR stdout", stdout)
    append_log(job, "Python OCR stderr", stderr)
    if code != 0 or not partial_path.exists():
        add_event(
            job,
            "warn",
            "Python OCR could not finish",
            "Python did not produce a per-file extraction report. Codex will read all uploaded sources.",
        )
        update_job(
            job,
            status="fallback",
            phase="codex-fallback",
            method="Codex fallback",
            message="Python OCR could not complete. Codex is reading all uploaded documents now.",
        )
        return False

    partial = json.loads(partial_path.read_text(encoding="utf-8"))
    job["partial_extraction_path"] = str(partial_path)
    job["hybrid_summary"] = partial.get("summary", {})
    needs_codex = records_needing_codex(partial)
    total = len(partial_records(partial))
    python_count = total - len(needs_codex)
    if not needs_codex:
        add_event(
            job,
            "ok",
            "Python OCR completed",
            f"Python read all {total} source(s) in {format_seconds(ocr_seconds)}.",
        )
        await build_workbook_from_extraction(
            job,
            partial,
            partial_path,
            method="Python OCR",
            ready_message="Excel workbook is ready. Python OCR read all required fields.",
        )
        return True

    failed_names = ", ".join(f"{record.get('section')} {record.get('index')} {record.get('source')}" for record in needs_codex[:5])
    if len(needs_codex) > 5:
        failed_names += f", and {len(needs_codex) - 5} more"
    add_event(
        job,
        "warn",
        "Python OCR needs Codex help",
        f"Python read {python_count}/{total} source(s). Codex will read only: {failed_names}.",
    )
    update_job(
        job,
        status="fallback",
        phase="codex-fallback",
        method="Hybrid OCR",
        message=f"Python OCR read {python_count}/{total} source(s). Codex will read only {len(needs_codex)} unreadable source(s).",
    )
    return False


def render_pdf(path: Path, target_dir: Path, prefix: str) -> list[Path]:
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. Install requirements.txt before PDF fallback.")
    rendered: list[Path] = []
    doc = fitz.open(path)
    try:
        for page_index in range(doc.page_count):
            page = doc.load_page(page_index)
            pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
            out = target_dir / f"{prefix}_page_{page_index + 1:02d}.png"
            pix.save(out)
            rendered.append(out)
    finally:
        doc.close()
    return rendered


def convert_image(path: Path, target_dir: Path, prefix: str) -> Path:
    if Image is None:
        raise RuntimeError("Pillow is not installed. Install requirements.txt before image fallback.")
    out = target_dir / f"{prefix}.png"
    with Image.open(path) as image:
        image.convert("RGB").save(out)
    return out


def prepare_codex_images(job: dict[str, Any], targets: list[dict[str, Any]] | None = None) -> list[tuple[str, Path]]:
    image_dir = Path(job["job_dir"]) / "codex_images"
    image_dir.mkdir(parents=True, exist_ok=True)
    prepared: list[tuple[str, Path]] = []
    if targets is None:
        targets = []
        for section in ("load", "discharge"):
            source_key = "load_files" if section == "load" else "discharge_files"
            for index, source in enumerate(job[source_key], start=1):
                targets.append({"section": section, "index": index, "source_path": str(source), "source": source.name})
    for target in targets:
        section = str(target.get("section") or "")
        index = int(target.get("index") or 0)
        source = Path(str(target.get("source_path") or ""))
        suffix = source.suffix.lower()
        prefix = f"{section}_{index:02d}_{source.stem}"
        label_base = f"{section} file {index}: {source.name}"
        if suffix == ".pdf":
            for page_number, page_path in enumerate(render_pdf(source, image_dir, prefix), start=1):
                prepared.append((f"{label_base} page {page_number}", page_path))
        elif suffix in IMAGE_SUFFIXES:
            prepared.append((label_base, source))
        elif suffix in CONVERTIBLE_IMAGE_SUFFIXES:
            prepared.append((label_base, convert_image(source, image_dir, prefix)))
        else:
            raise RuntimeError(f"Unsupported fallback file type: {source.name}")
    return prepared


def codex_prompt(job: dict[str, Any], images: list[tuple[str, Path]], targets: list[dict[str, Any]] | None = None) -> str:
    image_list = "\n".join(f"- {label}" for label, _path in images)
    if targets:
        load_targets = [target for target in targets if target.get("section") == "load"]
        discharge_targets = [target for target in targets if target.get("section") == "discharge"]
        scope_note = textwrap.dedent(
            f"""
            Python OCR already read the other uploaded files. Only extract the attached unreadable files.
            Return the load array with exactly {len(load_targets)} item(s), in the attached loading-file order.
            Return the discharge array with exactly {len(discharge_targets)} item(s), in the attached discharge-file order.
            Do not create placeholder sections for files that were already handled by Python OCR.
            """
        ).strip()
    else:
        scope_note = "Read every attached file and return all loading/discharge sections in upload order."
    return textwrap.dedent(
        f"""
        You are a visual extraction worker for DEM claim Excel generation.
        Do not inspect local files, search the repository, run shell commands, browse the web, or use tools.
        Use only the attached images and the rules in this prompt.

        Read the attached SOF/time-sheet images and return extraction JSON only.
        {scope_note}

        Attached files:
        {image_list}

        Required load events: NOR tendered, all fast, hose on, load commence, load complete, hose off.
        Anchor up is useful and should be extracted when present.
        Required discharge events: NOR tendered, anchor up, all fast, hose on, discharge commence, discharge complete, hose off.

        Event row mapping:
        - load nor_tendered: NOR tendered / NOR notice row.
        - load all_fast: all fast / alongside at berth row.
        - load hose_on: completed hose connecting / hose on row.
        - load load_commence: commenced loading row.
        - load load_complete: completed loading row.
        - load hose_off: completed disconnecting / hose off row.
        - discharge nor_tendered: NOR tendered / NOR notice row.
        - discharge anchor_up: anchor up shifting to berth row; use null if the row is blank or crossed out.
        - discharge all_fast: all fast / alongside at berth row.
        - discharge hose_on: completed hose connecting / hose on row.
        - discharge disch_commence: commenced loading/discharging row.
        - discharge disch_complete: completed loading/discharging row.
        - discharge hose_off: completed disconnecting / hose off row.

        Use YYYY-MM-DD HH:MM for event values and YYYY-MM-DD for date-only metadata.
        Preserve leading zero hours such as 06:30.
        Convert handwritten compact times like 0630 to 06:30.
        Use null for any value you cannot read confidently.
        Put uncertainty in confidence_notes as field/note objects.
        Do not invent missing values.
        Before finalizing, re-check each required event against its original row.
        For handwritten times, inspect each digit carefully; do not round or infer a cleaner value from nearby rows.
        Pay special attention to ambiguous 0/2/5/7 digits.

        Build the JSON shape expected by dem_claim_from_json.py:
        metadata, load array, discharge array, confidence_notes array.
        """
    ).strip()


async def run_codex_fallback(job: dict[str, Any]) -> None:
    partial_path_value = job.get("partial_extraction_path")
    partial = json.loads(Path(partial_path_value).read_text(encoding="utf-8")) if partial_path_value else None
    targets = records_needing_codex(partial) if isinstance(partial, dict) else None
    prepared = prepare_codex_images(job, targets)
    if not prepared:
        raise RuntimeError("No images were available for Codex fallback.")
    add_event(
        job,
        "info",
        "Files prepared for Codex",
        f"{len(prepared)} image page(s) from {len(targets) if targets is not None else 'all'} source(s) will be read visually.",
    )

    job_dir = Path(job["job_dir"])
    schema_path = job_dir / "codex_extraction_schema.json"
    codex_extraction_path = job_dir / "codex_extraction.json"
    extraction_path = job_dir / "extraction.json"
    schema_path.write_text(json.dumps(CODEX_EXTRACTION_SCHEMA, indent=2), encoding="utf-8")

    prompt = codex_prompt(job, prepared, targets)
    cmd = [
        CODEX_BIN,
        "exec",
        "--ephemeral",
        "--ignore-rules",
        "--skip-git-repo-check",
        "-m",
        CODEX_FALLBACK_MODEL,
        "-c",
        f'model_reasoning_effort="{CODEX_FALLBACK_REASONING_EFFORT}"',
        "--sandbox",
        "read-only",
        "--output-schema",
        str(schema_path),
        "-o",
        str(codex_extraction_path),
        prompt,
    ]
    if CODEX_FALLBACK_CLEAN_CONFIG:
        cmd.insert(2, "--ignore-user-config")
    for _label, path in prepared:
        cmd.extend(["--image", str(path)])

    update_job(
        job,
        status="fallback",
        phase="codex-reading",
        method="Hybrid OCR" if partial else "Codex fallback",
        message=(
            f"Codex is reading {len(targets)} unreadable source(s) visually."
            if targets is not None
            else "Codex is reading the uploaded files visually. This is usually the longest step."
        ),
    )
    add_event(
        job,
        "warn",
        "Codex visual reading started",
        "Using the signed-in local Codex CLI to read only the source files Python could not extract.",
    )
    codex_started = time.perf_counter()
    code, stdout, stderr = await run_command(cmd, cwd=job_dir, timeout=900, job=job)
    codex_seconds = time.perf_counter() - codex_started
    job.setdefault("timings", {})["codex_fallback"] = round(codex_seconds, 1)
    append_log(job, "Codex stdout", stdout)
    append_log(job, "Codex stderr", stderr)
    if code != 0:
        detail = (stderr or stdout).strip()
        detail_tail = detail[-1400:] if detail else "No Codex error detail was returned."
        if "usage limit" in detail.lower():
            raise RuntimeError(f"Codex fallback hit the current account usage limit. {detail_tail}")
        raise RuntimeError(f"Codex fallback failed with exit code {code}. {detail_tail}")
    if not codex_extraction_path.exists():
        codex_extraction_path.write_text(stdout.strip(), encoding="utf-8")
    add_event(
        job,
        "ok",
        "Codex finished reading",
        f"Visual reading took {format_seconds(codex_seconds)}. Creating the Excel file now.",
    )

    codex_extraction = json.loads(codex_extraction_path.read_text(encoding="utf-8"))
    extraction = merge_hybrid_extraction(partial, codex_extraction) if isinstance(partial, dict) else codex_extraction
    extraction["confidence_notes"] = normalize_confidence_notes(extraction.get("confidence_notes"))
    extraction_path.write_text(json.dumps(extraction, indent=2, ensure_ascii=False), encoding="utf-8")

    method = "Hybrid OCR" if isinstance(partial, dict) else "Codex fallback"
    summary = job.get("hybrid_summary") or {}
    ready_message = (
        f"Excel workbook is ready. Python OCR read {summary.get('python_complete', 0)} source(s); "
        f"Codex read {summary.get('needs_codex', len(targets or []))} source(s)."
        if isinstance(partial, dict)
        else "Excel workbook is ready. Codex read the fields Python could not extract."
    )
    await build_workbook_from_extraction(
        job,
        extraction,
        extraction_path,
        method=method,
        ready_message=ready_message,
    )


async def process_job(job_id: str) -> None:
    job = jobs.get(job_id)
    if not job:
        return
    try:
        check_paths()
        deterministic_ok = await run_deterministic(job)
        if deterministic_ok:
            return
        await run_codex_fallback(job)
    except asyncio.CancelledError:
        if job_id in jobs:
            append_log(job, "Canceled", "Task was removed by the user.")
            add_event(job, "fail", "Job canceled", "Task was removed by the user.")
            update_job(job, status="failed", phase="failed", message="Task canceled.")
        raise
    except Exception as exc:
        append_log(job, "Error", str(exc))
        add_event(job, "fail", "Job failed", str(exc))
        update_job(job, status="failed", phase="failed", message=str(exc))
    finally:
        job_tasks.pop(job_id, None)


def package_ok(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


def codex_auth_ok() -> bool:
    codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")).expanduser()
    auth_path = codex_home / "auth.json"
    if not auth_path.exists():
        return False
    try:
        auth = json.loads(auth_path.read_text(encoding="utf-8"))
    except Exception:
        return False
    return bool(auth.get("tokens") or auth.get("OPENAI_API_KEY") or auth.get("api_key"))


async def stop_process(proc: Any) -> None:
    if not proc or proc.returncode is not None:
        return
    with contextlib.suppress(ProcessLookupError):
        proc.terminate()
    with contextlib.suppress(asyncio.TimeoutError):
        await asyncio.wait_for(proc.wait(), timeout=3)
    if proc.returncode is None:
        with contextlib.suppress(ProcessLookupError):
            proc.kill()
        await proc.wait()


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    index_path = BASE_DIR / "static" / "index.html"
    if index_path.exists():
        return index_path.read_text(encoding="utf-8")
    return HTML


@app.get("/api/setup")
async def setup_status() -> JSONResponse:
    skill_root_ok = SKILL_ROOT.exists()
    scripts_ok = all(
        (SKILL_ROOT / "scripts" / name).exists()
        for name in ("dem_claim_extract_partial.py", "dem_claim_from_json.py")
    )
    codex_ok = bool(Path(CODEX_BIN).exists() or shutil.which(CODEX_BIN))
    tesseract_ok = bool(shutil.which("tesseract"))
    package_status = {
        "fastapi": package_ok("fastapi"),
        "openpyxl": package_ok("openpyxl"),
        "PIL": package_ok("PIL"),
        "pypdf": package_ok("pypdf"),
        "fitz": package_ok("fitz"),
    }
    return JSONResponse(
        {
            "skill_root": str(SKILL_ROOT),
            "skill_root_ok": skill_root_ok and scripts_ok,
            "codex_bin": CODEX_BIN,
            "codex_ok": codex_ok,
            "codex_auth_ok": codex_auth_ok(),
            "tesseract_ok": tesseract_ok,
            "packages": package_status,
            "packages_ok": all(package_status.values()),
        }
    )


@app.post("/api/jobs", status_code=202)
async def create_job(
    load_files: Annotated[list[UploadFile], File()],
    discharge_files: Annotated[list[UploadFile], File()],
    task_number: Annotated[str | None, Form()] = None,
) -> JSONResponse:
    if not load_files:
        raise HTTPException(status_code=400, detail="At least one loading file is required.")
    if not discharge_files:
        raise HTTPException(status_code=400, detail="At least one discharge file is required.")

    JOB_ROOT.mkdir(parents=True, exist_ok=True)
    job_id = uuid.uuid4().hex[:12]
    job_dir = JOB_ROOT / job_id
    job_dir.mkdir(parents=True, exist_ok=False)
    saved_load = await save_uploads(job_dir, "load", load_files)
    saved_discharge = await save_uploads(job_dir, "discharge", discharge_files)

    job = {
        "job_id": job_id,
        "task_number": normalize_task_number(task_number),
        "job_dir": str(job_dir),
        "status": "queued",
        "phase": "queued",
        "method": "pending",
        "message": "Files uploaded. Waiting to start.",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "load_files": saved_load,
        "discharge_files": saved_discharge,
        "events": [],
        "warnings": [],
        "timings": {},
        "log": "",
    }
    add_event(
        job,
        "info",
        "Job queued",
        f"{len(saved_load)} loading file(s), {len(saved_discharge)} discharge file(s).",
    )
    jobs[job_id] = job
    job_tasks[job_id] = asyncio.create_task(process_job(job_id))
    return JSONResponse(public_job(job), status_code=202)


@app.get("/api/jobs/download-all")
async def download_all_jobs(items: str = "") -> FileResponse:
    parsed = parse_download_items(items)
    if not parsed:
        completed = [
            job
            for job in sorted(jobs.values(), key=lambda item: item.get("created_at", ""))
            if job.get("status") == "completed"
        ]
        parsed = [(job["job_id"], normalize_task_number(job.get("task_number"))) for job in completed]

    zip_path = JOB_ROOT / f"all_task_excels_{uuid.uuid4().hex[:8]}.zip"
    used_names: set[str] = set()
    count = 0
    with ZipFile(zip_path, "w", ZIP_DEFLATED) as archive:
        for job_id, task_number in parsed:
            job = jobs.get(job_id)
            output_value = job.get("output_path") if job else None
            output = Path(output_value) if output_value else None
            if not job or job.get("status") != "completed" or not output or not output.exists():
                continue
            filename = task_excel_filename(task_number or job.get("task_number"))
            archive.write(output, unique_archive_name(filename, used_names))
            count += 1
    if count == 0:
        zip_path.unlink(missing_ok=True)
        raise HTTPException(status_code=404, detail="No completed workbooks are ready to download.")
    return FileResponse(
        zip_path,
        filename="all_task_excels.zip",
        media_type="application/zip",
        background=BackgroundTask(lambda: zip_path.unlink(missing_ok=True)),
    )


@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str) -> JSONResponse:
    job = jobs.pop(job_id, None)
    task = job_tasks.pop(job_id, None)
    if task and not task.done():
        task.cancel()
    if job:
        await stop_process(job.get("current_process"))
    return JSONResponse({"deleted": bool(job), "job_id": job_id})


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str) -> JSONResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return JSONResponse(public_job(job))


@app.get("/api/jobs/{job_id}/download")
async def download_job(job_id: str, task: int | None = None) -> FileResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    output = job.get("output_path")
    if job.get("status") != "completed" or not output or not Path(output).exists():
        raise HTTPException(status_code=404, detail="Workbook is not ready.")
    return FileResponse(
        output,
        filename=task_excel_filename(task or job.get("task_number")),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="127.0.0.1", port=int(os.environ.get("PORT", "8000")), reload=False)
