---
name: dem-claim-excel
description: Build fixed-format DEM claim Excel workbooks from load/discharge statement-of-facts PDFs, images, scanned tables, typed SOF forms, or handwritten time sheets. Use when Codex needs to extract DEM claim event dates/times, run the bundled Python OCR/workbook builder, fall back to AI vision for fields Python cannot read, validate the extracted values, or create a portable DEM claim workflow for another computer.
---

# DEM Claim Excel

## Overview

Use the bundled Python as the deterministic first pass and workbook writer. Use AI vision only as a fallback for handwritten or unclear fields, then pass the extracted values back into Python as JSON so the Excel layout, formulas, and block structure stay fixed.

The skill is portable: the `scripts/` directory contains the Python workflow, `assets/DEM_CLAIM_TEMPLATE.xlsx` contains the workbook template, `web/` contains the local upload website, and `scripts/requirements.txt` contains Python package requirements. If the `.xlsx` template is accidentally deleted, `scripts/dem_claim_template.py` can recreate the current template from embedded Python bytes, and the workbook builders call it automatically before loading the template.

## Workflow

1. Run `python scripts/dem_claim_setup_check.py` from the skill root to verify Python packages, the bundled template, and Tesseract.
2. Install missing Python packages with `python -m pip install -r scripts/requirements.txt`.
3. Run deterministic extraction first:

```bash
python scripts/dem_claim_deterministic.py \
  --load-source /path/to/load.png \
  --discharge-source /path/to/discharge.png \
  --output /path/to/output.xlsx \
  --debug-dir /path/to/debug
```

4. If deterministic extraction succeeds and the printed values match the sources, deliver the workbook.
5. If extraction fails or has missing/uncertain fields, read `references/ai-fallback-guide.md` and `references/extraction-schema.md`.
6. Use AI vision to inspect only the failed original files/pages or debug crops. Keep deterministic Python values for files that were fully read, and create strict extraction JSON for the unreadable files.
7. Apply the JSON:

```bash
python scripts/dem_claim_from_json.py \
  --json /path/to/extraction.json \
  --output /path/to/output.xlsx
```

8. Read the generated `.report.json`, check warnings, and spot-check the workbook against the source images before delivering it.

## Deterministic Path

Prefer deterministic extraction for readable PDFs and typed SOF images. It is cheaper, repeatable, and already maps event values to the fixed Excel cells.

For multiple load or discharge sections, pass sources in workbook order:

```bash
python scripts/dem_claim_deterministic.py \
  --load-source load1.png load2.png \
  --discharge-source discharge1.png discharge2.png \
  --output dem_claim.xlsx \
  --debug-dir debug_ocr
```

If a required event is missing in a source, keep any other source files that Python fully extracted and use the AI fallback only for the failed source files. Do not silently write a workbook with guessed values.

## AI Vision Fallback

Use the fallback when the source is handwritten, scanned poorly, or a different table family from the typed SOF forms. The AI role is extraction only:

- Read labels, dates, times, ports, quantities, and metadata from the image.
- Return JSON following `references/extraction-schema.md`.
- Put uncertain values as `null` or add a confidence note.
- Let `scripts/dem_claim_from_json.py` write the workbook.

For handwritten time sheets, map rows using `references/ai-fallback-guide.md`. Use original source images for final reading; debug OCR text is helpful context but not authority.

## Local Website

Run the local website when the user wants a browser UI with separate loading/discharge upload inputs and downloadable Excel output. The website supports multiple independent task cards and a Start All control for ready cards, so a user can run several DEM claims at the same time without mixing one claim's loading/discharge documents into another claim.

```bash
cd ~/.codex/skills/dem-claim-excel
python -m pip install -r scripts/requirements.txt
python scripts/dem_claim_setup_check.py
python web/app.py
```

Open http://127.0.0.1:8000.

The website runs deterministic Python OCR first. It records which individual loading/discharge source files were fully read. If only some files are unreadable, it renders just those files to images as needed and calls local `codex exec` with image attachments and a strict JSON schema, then merges Python-read sections and Codex-read sections back into the original workbook order. If Codex can read the file but the source leaves a required event blank, the website builds the workbook with warnings so the user can download and review it. The Codex fallback uses the Codex login on the current computer, not `OPENAI_API_KEY`. The target computer must have Codex CLI installed and logged in for automatic fallback to work.

The local website keeps Codex fallback fast by running `codex exec` in a clean per-job folder, ignoring user config by default, and setting `model_reasoning_effort` to `medium`. Override these only when needed:

```bash
CODEX_FALLBACK_MODEL=gpt-5.5 \
CODEX_FALLBACK_REASONING_EFFORT=high \
CODEX_FALLBACK_CLEAN_CONFIG=0 \
python web/app.py
```

Keep the prompt's event row mapping and handwritten digit self-check when tuning fallback speed; these guard against fast visual reads changing ambiguous handwritten times.

## Validation Rules

- Required load events: NOR tendered, all fast, hose on, load commence, load complete, hose off. Anchor up is useful for shifting calculations and should be extracted when present.
- Required discharge events: NOR tendered, anchor up, all fast, hose on, discharge commence, discharge complete, hose off.
- Use `YYYY-MM-DD HH:MM` for event values.
- Preserve leading zero hours such as `06:30`.
- Compare extracted values against source rows before final delivery.
- Review `.report.json` warnings after JSON-based builds.

## Copying To Another Computer

Copy the whole `dem-claim-excel` folder to the other computer's Codex skills directory, usually `~/.codex/skills/dem-claim-excel`.

Then run:

```bash
cd ~/.codex/skills/dem-claim-excel
python -m pip install -r scripts/requirements.txt
python scripts/dem_claim_setup_check.py
```

Install Tesseract if typed image OCR is needed. Install and log in to Codex CLI if the local website should automatically run the Codex fallback. The AI fallback can still be used by Codex for visual reading when Python OCR cannot read handwriting.

If `assets/DEM_CLAIM_TEMPLATE.xlsx` is missing, restore it with:

```bash
python scripts/dem_claim_template.py
```

The setup check and workbook generation also restore the current embedded template automatically when that file is missing.

To run the browser uploader on the other computer:

```bash
python web/app.py
```
