# DEM Claim Extraction JSON

Use this schema when deterministic OCR misses values and AI vision must read handwritten or unclear fields. Return JSON only. Use `null` for values that cannot be read with confidence.

## Top-Level Shape

```json
{
  "metadata": {
    "charterer": "CNOOC and Shell Petrochemicals Company Ltd",
    "charterer_ref": "SY21625050J",
    "owner": "HAINAN SHUNYUAN SHIPPING",
    "owner_ref": "Shun Yuan 216 V.2511",
    "broker": "SPI Marine Consulting (Shanghai) Co.,Ltd",
    "vessel": "Shun Yuan 216",
    "cp_date": "2025-04-29",
    "demurrage_rate": 55000,
    "total_cargo_quantity": 2000.5,
    "currency": "RMB",
    "laycan_start": "2025-05-02",
    "laycan_end": "2025-05-05",
    "doc_date": "2025-05-19"
  },
  "load": [
    {
      "port": "Huizhou",
      "berth": "Donglian",
      "terminal": "BD",
      "allowed_hours": 36,
      "events": {
        "nor_tendered": "2025-05-06 12:50",
        "anchor_up": "2025-05-09 14:35",
        "all_fast": "2025-05-09 16:20",
        "hose_on": "2025-05-09 18:15",
        "load_commence": "2025-05-09 18:32",
        "load_complete": "2025-05-10 08:43",
        "hose_off": "2025-05-10 10:50"
      }
    }
  ],
  "discharge": [
    {
      "port": "Nantong",
      "berth": "Qianhong",
      "quantity": 2000.5,
      "rate": 150,
      "allowed_hours": 36,
      "events": {
        "nor_tendered": "2025-05-13 01:00",
        "anchor_up": "2025-05-14 04:50",
        "all_fast": "2025-05-14 17:50",
        "hose_on": "2025-05-14 18:50",
        "disch_commence": "2025-05-14 19:20",
        "disch_complete": "2025-05-15 06:30",
        "hose_off": "2025-05-15 07:25"
      },
      "deductions": {
        "rate_difference_hours": null,
        "night_navigation_hours": null,
        "document_onboard_hours": 0
      }
    }
  ],
  "confidence_notes": {
    "load.1.events.load_complete": "medium; handwritten 0843 could be 0840",
    "discharge.1.events.nor_tendered": "high; row and value are clear"
  }
}
```

## Canonical Event Keys

Load events:
- `nor_tendered`
- `anchor_up`
- `all_fast`
- `hose_on`
- `load_commence`
- `load_complete`
- `hose_off`

Discharge events:
- `nor_tendered`
- `anchor_up`
- `all_fast`
- `hose_on`
- `disch_commence`
- `disch_complete`
- `hose_off`

## Rules

- Use `YYYY-MM-DD HH:MM` for event datetimes.
- Use `YYYY-MM-DD` for date-only metadata.
- Convert handwritten dates like `5.10`, `5/10`, or `5-10` using the document year.
- Preserve leading zero hours: `0630` becomes `06:30`.
- If a time range is shown for hose disconnect/connecting, use the end time only when the workbook field is "HOSE OFF"; otherwise use the start time unless the source clearly means completion.
- Do not invent missing values. Use `null` and add a confidence note.
