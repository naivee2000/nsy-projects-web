# AI Vision Fallback Guide

Use this only after the deterministic Python workflow fails, misses required events, or produces low-confidence values.

## Workflow

1. Run deterministic extraction first with `scripts/dem_claim_deterministic.py`.
2. If it fails, inspect the debug text and crops. Determine which section failed: load, discharge, metadata, or both.
3. Open the original source image/PDF page and, when useful, crop the table rows around only the missing fields.
4. Read the handwritten/unclear values visually and write extraction JSON using `references/extraction-schema.md`.
5. Apply the JSON with `scripts/dem_claim_from_json.py`.
6. Verify the generated workbook by opening the report JSON and checking event chronology, missing fields, and any confidence notes.

## Reading Handwritten Time Sheets

For time-sheet style images with columns like `Item`, `Time`, and `Date`, map rows this way:

- `NOR tendered` -> `nor_tendered`
- `Anchor up shifting to berth` -> `anchor_up`
- `First line to berth` or `Alongside at berth` -> `all_fast`; prefer `Alongside at berth` when both exist
- `Completed hose connecting` -> `hose_on`
- `Commenced loading/discharging` -> `load_commence` for load sources, `disch_commence` for discharge sources
- `Completed loading/discharging` -> `load_complete` for load sources, `disch_complete` for discharge sources
- `Completed disconnecting` -> `hose_off`

Use the document year from the page header or nearby metadata. If only month/day appears in the table, combine that month/day with the document year.

## Confidence Discipline

- Mark a value `high` only when both row label and value are clear.
- Mark a value `medium` when row label is clear but handwriting has one plausible alternate reading.
- Use `null` when there are two or more plausible readings or the row is obscured.
- Never resolve a doubtful value by forcing the workbook to balance.
- If a value came from AI vision rather than deterministic OCR, preserve that fact in `confidence_notes`.
